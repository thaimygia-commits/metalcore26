import React from 'react';
import { BookOpen, ExternalLink, ArrowUp, Heart } from 'lucide-react';
import { soundManager } from '../utils/soundFx';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    soundManager.playBubblePop();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative bg-slate-950 border-t border-slate-800/80 pt-12 sm:pt-16 pb-10 sm:pb-12 px-3.5 sm:px-6 lg:px-8 w-full overflow-hidden">
      <div className="max-w-7xl mx-auto w-full">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 sm:gap-10 pb-10 sm:pb-12 border-b border-slate-800">
          {/* Brand & Project Info */}
          <div className="space-y-3 sm:space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 to-cyan-400 p-0.5">
                <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center font-black text-sky-400 text-xs">
                  e⁻
                </div>
              </div>
              <span className="font-extrabold text-base sm:text-lg tracking-wider text-white">METAL CORE</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Tạp chí khoa học & chuyên đề Đại Cương Kim Loại Hóa Học 12. Tích hợp đọc tạp chí điện tử số Heyzine 3D kết hợp 6 mini-games học tập sáng tạo cùng linh vật Bé Electron.
            </p>
            <div className="text-xs text-sky-400 font-semibold">
              Nhóm 06 – Lớp 12A2 (Năm học 2026 - 2027)
            </div>
          </div>

          {/* Authors */}
          <div>
            <h4 className="font-bold text-xs sm:text-sm text-white uppercase tracking-wider mb-3 text-sky-300">
              Nhóm Tác Giả Thực Hiện
            </h4>
            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0" />
                <span>Thái Mỹ Gia</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0" />
                <span>Bành Lâm Tường Ngân</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0" />
                <span>Nguyễn Huỳnh Ngọc Như</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0" />
                <span>Nguyễn Hồ Hải Nhi</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0" />
                <span>Nguyễn Thị Minh</span>
              </li>
            </ul>
          </div>

          {/* Integrated Student Web Apps */}
          <div>
            <h4 className="font-bold text-xs sm:text-sm text-white uppercase tracking-wider mb-3 text-sky-300">
              Hệ Thống Web Tích Hợp
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <a 
                  href="https://matchacoco222.github.io/save-the-ship/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-sky-300 flex items-center justify-between group transition-colors"
                >
                  <span className="truncate">Save The Ship (Cứu Tàu)</span>
                  <ExternalLink className="w-3 h-3 group-hover:translate-x-0.5 transition-transform shrink-0 ml-1" />
                </a>
              </li>
              <li>
                <a 
                  href="https://matchacoco222.github.io/es-cape-room/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-sky-300 flex items-center justify-between group transition-colors"
                >
                  <span className="truncate">Escape Room (Vượt Ngục Hóa)</span>
                  <ExternalLink className="w-3 h-3 group-hover:translate-x-0.5 transition-transform shrink-0 ml-1" />
                </a>
              </li>
              <li>
                <a 
                  href="https://matchacoco222.github.io/elec-tronnn/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-sky-300 flex items-center justify-between group transition-colors"
                >
                  <span className="truncate">Electron Escape Game</span>
                  <ExternalLink className="w-3 h-3 group-hover:translate-x-0.5 transition-transform shrink-0 ml-1" />
                </a>
              </li>
              <li>
                <a 
                  href="https://matchacoco222.github.io/tham-tu/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-sky-300 flex items-center justify-between group transition-colors"
                >
                  <span className="truncate">Thám Tử Hóa Học</span>
                  <ExternalLink className="w-3 h-3 group-hover:translate-x-0.5 transition-transform shrink-0 ml-1" />
                </a>
              </li>
              <li>
                <a 
                  href="https://matchacoco222.github.io/hopkim/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-sky-300 flex items-center justify-between group transition-colors"
                >
                  <span className="truncate">Thế Giới Hợp Kim (Hopkim)</span>
                  <ExternalLink className="w-3 h-3 group-hover:translate-x-0.5 transition-transform shrink-0 ml-1" />
                </a>
              </li>
              <li>
                <a 
                  href="https://matchacoco222.github.io/chuong6/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-sky-300 flex items-center justify-between group transition-colors"
                >
                  <span className="truncate">Ôn Tập Chương 6 Kim Loại</span>
                  <ExternalLink className="w-3 h-3 group-hover:translate-x-0.5 transition-transform shrink-0 ml-1" />
                </a>
              </li>
            </ul>
          </div>

          {/* Flipbook & Actions */}
          <div className="space-y-3 sm:space-y-4">
            <h4 className="font-bold text-xs sm:text-sm text-white uppercase tracking-wider text-sky-300">
              Tài Liệu Gốc Heyzine
            </h4>
            <div className="p-3 sm:p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-sky-400" />
                <span>Heyzine Flipbook 3D</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Phiên bản PDF lật trang 40 trang hoàn chỉnh với âm thanh & hiệu ứng trang 3D.
              </p>
              <a
                href="https://heyzine.com/flip-book/0403fd6e29.html"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 w-full py-2 px-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <span>Xem trên Heyzine</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            <button
              onClick={scrollToTop}
              className="w-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white font-medium text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <ArrowUp className="w-3.5 h-3.5" />
              <span>Lên đầu trang</span>
            </button>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-6 sm:pt-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 text-center sm:text-left">
          <div>
            © 2026 - 2027 METAL CORE Magazine • Nhóm 06 - Lớp 12A2 (Năm học 2026 - 2027).
          </div>
          <div className="flex items-center gap-1 text-slate-400 justify-center">
            <span>Thiết kế vì niềm say mê Hóa Học</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
            <span>cùng Bé Electron</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
