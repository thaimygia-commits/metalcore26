import React, { useState } from 'react';
import { InteractiveStation } from '../types';
import { soundManager } from '../utils/soundFx';
import { 
  Gamepad2, 
  ExternalLink, 
  Sparkles, 
  ShieldAlert, 
  Search, 
  Cpu, 
  Layers, 
  GraduationCap, 
  Maximize2, 
  Minimize2, 
  RotateCcw, 
  X,
  BookOpen,
  ArrowRight
} from 'lucide-react';

const STATIONS: InteractiveStation[] = [
  {
    id: 'save-the-ship',
    title: 'Save The Ship | Giải Cứu Con Tàu',
    category: 'game',
    url: 'https://matchacoco222.github.io/save-the-ship/',
    description: 'Trò chơi mô phỏng cơ chế ăn mòn điện hóa kim loại trong nước biển. Bạn phải gắn các khối Kẽm (Zn) hi sinh để bảo vệ thân tàu sắt thép (Fe) trước sự tàn phá của muối và oxy!',
    pageInFlipbook: 36,
    highlightTag: 'Chuyên đề Ăn mòn điện hóa',
    color: 'from-blue-600 to-cyan-500',
    icon: 'ship',
    electronHint: 'Hãy gắn Kẽm (Zn) lên vỏ tàu sắt (Fe)! Zn có tính khử mạnh hơn Fe nên sẽ bị oxi hóa trước, bảo vệ Fe nguyên vẹn!'
  },
  {
    id: 'es-cape-room',
    title: 'Escape Room | Mật Mã Phòng Thí Nghiệm',
    category: 'puzzle',
    url: 'https://matchacoco222.github.io/es-cape-room/',
    description: 'Thử thách vượt ngục hóa học! Vận dụng kiến thức về dãy điện hóa, phản ứng kim loại với acid HNO3/H2SO4 và quy tắc alpha để tìm mật mã mở khóa cánh cửa thoát hiểm bí ẩn.',
    pageInFlipbook: 18,
    highlightTag: 'Chuyên đề Phản ứng Hóa học',
    color: 'from-amber-600 to-orange-500',
    icon: 'door',
    electronHint: 'Chú ý tính khử của các kim loại trong dãy điện hóa và các trường hợp thụ động hóa Al, Fe, Cr trong acid đặc nguội!'
  },
  {
    id: 'elec-tronnn',
    title: 'Electron Escape | Cuộc Đào Tẩu Của Electron',
    category: 'game',
    url: 'https://matchacoco222.github.io/elec-tronnn/',
    description: 'Đồng hành cùng bé Electron vượt qua các mạng tinh thể kim loại (lập phương tâm khối, lập phương tâm diện), né tránh các chướng ngại vật điện tích để tự do bơi trong biển electron!',
    pageInFlipbook: 9,
    highlightTag: 'Chuyên đề Cấu tạo & Liên kết',
    color: 'from-cyan-600 to-sky-400',
    icon: 'zap',
    electronHint: 'Bay khéo léo qua các cation kim loại mang điện tích dương và đừng để va chạm vào nút mạng nhé!'
  },
  {
    id: 'tham-tu',
    title: 'Thám Tử Hóa Học | Hồ Sơ Vụ Án Kim Loại',
    category: 'puzzle',
    url: 'https://matchacoco222.github.io/tham-tu/',
    description: 'Hóa thân thành thám tử phân tích mẫu vật kim loại bí ẩn thu được tại hiện trường. Nhận diện kim loại qua màu ngọn lửa, độ cứng, khối lượng riêng và phản ứng hóa học đặc trưng.',
    pageInFlipbook: 26,
    highlightTag: 'Chuyên đề Nhận biết & Tách kim loại',
    color: 'from-violet-600 to-purple-500',
    icon: 'search',
    electronHint: 'Kim loại nặng nhất là Osmium, nhẹ nhất là Lithium; kim loại cứng nhất là Crom; thử nhiệt độ nóng chảy của Wolfram!'
  },
  {
    id: 'hopkim',
    title: 'Thế Giới Hợp Kim | Metal Matrix Alloy',
    category: 'simulation',
    url: 'https://matchacoco222.github.io/hopkim/',
    description: 'Khám phá thế giới vật liệu tương lai: cấu trúc Gang và Thép (hợp kim Fe - C), siêu hợp kim Duralumin nhẹ chế tạo vỏ máy bay, hợp kim nhớ hình Nitinol và hợp kim vàng tây.',
    pageInFlipbook: 27,
    highlightTag: 'Chuyên đề Vật liệu & Hợp kim',
    color: 'from-emerald-600 to-teal-500',
    icon: 'layers',
    electronHint: 'Hợp kim thường cứng hơn, nhiệt độ nóng chảy thấp hơn và dẫn điện kém hơn kim loại nguyên chất ban đầu!'
  },
  {
    id: 'chuong6',
    title: 'Chương 6 Online | Trạm Ôn Luyện Kim Loại',
    category: 'review',
    url: 'https://matchacoco222.github.io/chuong6/',
    description: 'Cổng ôn tập toàn diện Đại cương kim loại lớp 12 với kho tàng bài tập tương tác, sơ đồ tư duy phản ứng và ngân hàng câu hỏi chuẩn cấu trúc đề thi THPT Quốc gia.',
    pageInFlipbook: 39,
    highlightTag: 'Chuyên đề Ôn tập tổng hợp',
    color: 'from-rose-600 to-pink-500',
    icon: 'book',
    electronHint: 'Luyện tập thường xuyên để ghi nhớ trọn vẹn dãy điện hóa và các phương pháp thủy luyện, nhiệt luyện, điện phân!'
  }
];

export const InteractiveStations: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activeStation, setActiveStation] = useState<InteractiveStation | null>(null);
  const [isFullscreenStation, setIsFullscreenStation] = useState<boolean>(false);
  const [iframeKey, setIframeKey] = useState<number>(0);

  const filteredStations = activeCategory === 'all' 
    ? STATIONS 
    : STATIONS.filter(s => s.category === activeCategory);

  const handleLaunchStation = (station: InteractiveStation) => {
    soundManager.playBubblePop();
    setActiveStation(station);
    setIframeKey(prev => prev + 1);
  };

  const handleCloseStation = () => {
    setActiveStation(null);
    setIsFullscreenStation(false);
  };

  const handleRefreshIframe = () => {
    soundManager.playBubblePop();
    setIframeKey(prev => prev + 1);
  };

  return (
    <section id="interactive-stations" className="relative py-14 sm:py-20 px-3.5 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full overflow-hidden">
      {/* Background Ambience Constrained */}
      <div className="absolute top-1/2 right-1/4 w-full max-w-2xl h-[280px] bg-sky-500/10 blur-[120px] pointer-events-none rounded-full" />

      {/* Section Header */}
      <div className="relative mb-8 sm:mb-12 text-center max-w-3xl mx-auto w-full">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-400/40 text-cyan-300 text-[11px] sm:text-xs font-semibold uppercase tracking-wider mb-3 shadow-inner">
          <Gamepad2 className="w-3.5 h-3.5 text-cyan-400" />
          Hệ Thống Trạm Học Tập Số Tích Hợp
        </div>

        <h2 className="text-2xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white mb-3 sm:mb-4">
          PHÒNG LAB & <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-400 bg-clip-text text-transparent">MINI-GAMES TƯƠNG TÁC</span>
        </h2>

        <p className="text-xs sm:text-base text-slate-300 font-light leading-relaxed">
          Tích hợp trực tiếp 6 ứng dụng khoa học & trò chơi hóa học bổ trợ từ tạp chí Metal Core. Trải nghiệm giải cứu tàu biển, vượt ngục hóa học, điều khiển electron và khám phá hợp kim ngay trên website!
        </p>

        {/* Category Filters */}
        <div className="mt-6 sm:mt-8 flex flex-wrap items-center justify-center gap-1.5 sm:gap-2">
          {[
            { id: 'all', label: 'Tất cả (6)' },
            { id: 'game', label: 'Game hóa học (2)' },
            { id: 'puzzle', label: 'Mật mã & Thám tử (2)' },
            { id: 'simulation', label: 'Mô phỏng vật liệu (1)' },
            { id: 'review', label: 'Ôn tập thi (1)' }
          ].map(cat => (
            <button
              key={cat.id}
              onClick={() => {
                setActiveCategory(cat.id);
                soundManager.playBubblePop();
              }}
              className={`px-3 py-1.5 sm:px-4 sm:py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                activeCategory === cat.id
                  ? 'bg-sky-500 text-white shadow-lg shadow-sky-500/30 scale-105'
                  : 'bg-slate-900/80 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 w-full">
        {filteredStations.map((station) => (
          <div
            key={station.id}
            className="group relative rounded-3xl bg-slate-900/80 border border-slate-800 p-4 sm:p-6 flex flex-col justify-between hover:border-sky-500/50 hover:bg-slate-900/95 transition-all duration-300 hover:-translate-y-1 shadow-xl hover:shadow-2xl hover:shadow-sky-500/10 w-full"
          >
            {/* Top Tag & Flipbook reference */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-[10px] sm:text-[11px] font-bold uppercase tracking-wider text-sky-400 bg-sky-950/90 px-2.5 py-1 rounded-full border border-sky-800/60 truncate max-w-[180px]">
                  {station.highlightTag}
                </span>
                <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1 bg-slate-800/80 px-2 py-0.5 rounded-lg shrink-0">
                  <BookOpen className="w-3 h-3 text-sky-400" />
                  Trang {station.pageInFlipbook}
                </span>
              </div>

              {/* Station Icon & Title */}
              <div className="flex items-start gap-3 mb-3">
                <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br ${station.color} flex items-center justify-center text-white shadow-lg shrink-0 group-hover:scale-105 transition-transform`}>
                  {station.icon === 'ship' && <ShieldAlert className="w-5 h-5 sm:w-6 sm:h-6" />}
                  {station.icon === 'door' && <Cpu className="w-5 h-5 sm:w-6 sm:h-6" />}
                  {station.icon === 'zap' && <Sparkles className="w-5 h-5 sm:w-6 sm:h-6" />}
                  {station.icon === 'search' && <Search className="w-5 h-5 sm:w-6 sm:h-6" />}
                  {station.icon === 'layers' && <Layers className="w-5 h-5 sm:w-6 sm:h-6" />}
                  {station.icon === 'book' && <GraduationCap className="w-5 h-5 sm:w-6 sm:h-6" />}
                </div>
                <div className="min-w-0">
                  <h3 className="font-bold text-base sm:text-lg text-white group-hover:text-sky-300 transition-colors leading-snug">
                    {station.title}
                  </h3>
                  <span className="text-[10px] sm:text-[11px] text-slate-500 font-mono block truncate">
                    {station.url.replace('https://', '')}
                  </span>
                </div>
              </div>

              {/* Description */}
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-3.5">
                {station.description}
              </p>

              {/* Electron Mascot Hint box */}
              <div className="p-2.5 sm:p-3 rounded-2xl bg-sky-950/50 border border-sky-900/60 mb-4 flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-sky-500/20 border border-sky-400 flex items-center justify-center text-[10px] text-sky-300 font-bold shrink-0 mt-0.5">
                  e⁻
                </span>
                <p className="text-[11px] text-sky-200 leading-snug">
                  <strong className="text-sky-400">Mẹo từ Bé Electron: </strong>
                  {station.electronHint}
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-3 border-t border-slate-800 flex items-center gap-2">
              <button
                onClick={() => handleLaunchStation(station)}
                className="flex-1 py-2 sm:py-2.5 px-3 rounded-xl bg-gradient-to-r from-sky-600 to-cyan-500 hover:from-sky-500 hover:to-cyan-400 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-lg shadow-sky-600/30 transition-all cursor-pointer"
              >
                <span>Chơi / Mở Trực Tiếp</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              
              <a
                href={station.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 sm:p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer shrink-0"
                title="Mở tab mới"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* Embedded Live Player Modal */}
      {activeStation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-200">
          <div 
            className={`relative w-full rounded-2xl sm:rounded-3xl bg-slate-900 border border-sky-500/40 shadow-2xl flex flex-col overflow-hidden transition-all ${
              isFullscreenStation ? 'w-screen h-screen rounded-none max-w-none' : 'max-w-6xl h-[88vh]'
            }`}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between px-3 sm:px-4 py-2.5 sm:py-3 bg-slate-900 border-b border-slate-800 shrink-0">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${activeStation.color} flex items-center justify-center text-white text-xs font-bold shrink-0`}>
                  e⁻
                </div>
                <div className="min-w-0">
                  <h3 className="font-bold text-xs sm:text-base text-white truncate">{activeStation.title}</h3>
                  <p className="text-[10px] sm:text-[11px] text-sky-400 hidden sm:block truncate">
                    Trang {activeStation.pageInFlipbook} trong tạp chí Metal Core • {activeStation.highlightTag}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1 sm:gap-2 shrink-0">
                <button
                  onClick={handleRefreshIframe}
                  className="p-1.5 sm:p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title="Tải lại trò chơi"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setIsFullscreenStation(!isFullscreenStation)}
                  className="p-1.5 sm:p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title={isFullscreenStation ? "Thu nhỏ" : "Toàn màn hình"}
                >
                  {isFullscreenStation ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </button>

                <a
                  href={activeStation.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 sm:p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title="Mở trong tab mới"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>

                <button
                  onClick={handleCloseStation}
                  className="p-1.5 sm:p-2 rounded-xl bg-rose-950/80 hover:bg-rose-900 text-rose-300 hover:text-white transition-colors cursor-pointer ml-1"
                  title="Đóng trạm học tập"
                >
                  <X className="w-4 h-4 sm:w-5 sm:h-5" />
                </button>
              </div>
            </div>

            {/* Embedded Live Iframe */}
            <div className="relative flex-1 w-full bg-slate-950 overflow-hidden">
              <iframe
                key={iframeKey}
                src={activeStation.url}
                title={activeStation.title}
                className="w-full h-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              />
            </div>

            {/* Modal Footer with Coach Tip */}
            <div className="px-3 sm:px-4 py-2 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between text-[11px] sm:text-xs text-slate-300 shrink-0">
              <div className="flex items-center gap-2 min-w-0">
                <span className="px-2 py-0.5 rounded-full bg-sky-950 text-sky-400 font-bold border border-sky-800/60 text-[10px] shrink-0">
                  Bé Electron Nhắc Bài
                </span>
                <span className="text-slate-300 truncate">{activeStation.electronHint}</span>
              </div>
              <a
                href="#flipbook-section"
                onClick={handleCloseStation}
                className="text-sky-400 hover:text-sky-300 underline font-medium text-xs hidden md:inline shrink-0"
              >
                Lật trang {activeStation.pageInFlipbook} tạp chí
              </a>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
