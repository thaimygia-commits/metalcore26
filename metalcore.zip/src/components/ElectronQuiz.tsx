import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { QuizQuestion } from '../types';
import { soundManager } from '../utils/soundFx';
import { 
  Sparkles, 
  HelpCircle, 
  CheckCircle2, 
  XCircle, 
  RotateCcw, 
  Award, 
  BookOpen, 
  ArrowRight,
  Trophy
} from 'lucide-react';

const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: "Các tính chất vật lí chung của kim loại như tính dẻo, tính dẫn điện, dẫn nhiệt và ánh kim chủ yếu do yếu tố nào sau đây gây ra?",
    options: [
      "Khối lượng riêng lớn của các nguyên tử kim loại",
      "Sự hiện diện của các electron tự do trong mạng tinh thể kim loại",
      "Liên kết cộng hóa trị bền vững giữa các nguyên tử",
      "Cấu trúc tinh thể dạng hình thoi phức tạp"
    ],
    correctIndex: 1,
    explanation: "Chính các electron tự do (như Bé Electron!) di chuyển hỗn loạn trong toàn bộ tinh thể kim loại đã tạo nên cả 4 tính chất vật lý chung: Dẻo, dẫn điện, dẫn nhiệt, ánh kim.",
    pageRef: 11
  },
  {
    id: 2,
    question: "Thứ tự giảm dần về tính dẫn điện của các kim loại thông dụng nào sau đây là đúng nhất?",
    options: [
      "Cu > Ag > Au > Al > Fe",
      "Ag > Cu > Au > Al > Fe",
      "Al > Cu > Ag > Fe > Au",
      "Ag > Au > Cu > Fe > Al"
    ],
    correctIndex: 1,
    explanation: "Bạc (Ag) dẫn điện tốt nhất, tiếp theo là Đồng (Cu), Vàng (Au), Nhôm (Al) và Sắt (Fe). Câu thần chú: 'Bạc Đồng Vàng Nhôm Sắt'.",
    pageRef: 12
  },
  {
    id: 3,
    question: "Kim loại nào sau đây có nhiệt độ nóng chảy cao nhất, thường được ứng dụng làm dây tóc bóng đèn sợi đốt?",
    options: [
      "Thủy ngân (Hg)",
      "Crom (Cr)",
      "Wolfram (W)",
      "Bạch kim (Pt)"
    ],
    correctIndex: 2,
    explanation: "Wolfram (W) có nhiệt độ nóng chảy cao nhất trong các kim loại, đạt xấp xỉ 3410°C, giúp dây tóc bóng đèn không bị nóng chảy khi phát sáng rực rỡ.",
    pageRef: 14
  },
  {
    id: 4,
    question: "Cặp acid nào sau đây ở trạng thái ĐẶC NGUỘI sẽ làm thụ động hóa các kim loại Al, Fe, Cr (không xảy ra phản ứng)?",
    options: [
      "HCl đặc và H₂SO₄ loãng",
      "HNO₃ đặc nguội và H₂SO₄ đặc nguội",
      "CH₃COOH và H₂CO₃",
      "H₂SO₄ loãng và HNO₃ loãng"
    ],
    correctIndex: 1,
    explanation: "Al, Fe và Cr bị thụ động hóa trong HNO₃ đặc nguội và H₂SO₄ đặc nguội do tạo màng oxide bảo vệ cực mỏng trên bề mặt, vì vậy có thể dùng thùng bằng nhôm hoặc sắt để chuyên chở các acid này ở trạng thái đặc nguội.",
    pageRef: 17
  },
  {
    id: 5,
    question: "Để bảo vệ vỏ tàu biển bằng thép (Fe) ngâm trong nước biển khỏi bị ăn mòn điện hóa, người ta thường gắn những khối kim loại nào vào vỏ tàu?",
    options: [
      "Khối Đồng (Cu)",
      "Khối Kẽm (Zn)",
      "Khối Bạc (Ag)",
      "Khối Chì (Pb)"
    ],
    correctIndex: 1,
    explanation: "Phương pháp điện hóa (bảo vệ catot): Kẽm (Zn) có tính khử mạnh hơn Fe, nên khi tạo pin điện hóa trong nước biển, Zn sẽ là anot bị ăn mòn hi sinh, bảo vệ vỏ thép Fe nguyên vẹn.",
    pageRef: 34
  },
  {
    id: 6,
    question: "Nguyên tắc chung để điều chế và tách kim loại từ hợp chất quặng trong tự nhiên là gì?",
    options: [
      "Oxi hóa ion kim loại thành nguyên tử tự do: Mⁿ⁺ → M + ne⁻",
      "Khử ion kim loại thành nguyên tử tự do: Mⁿ⁺ + ne⁻ → M",
      "Hòa tan ion kim loại vào nước cất vô trùng",
      "Nhiệt phân muối để tạo thành khí trơ"
    ],
    correctIndex: 1,
    explanation: "Nguyên tắc điều chế kim loại là khử cation kim loại thành nguyên tử tự do: Mⁿ⁺ + ne⁻ → M.",
    pageRef: 22
  },
  {
    id: 7,
    question: "Các kim loại hoạt động hóa học mạnh (từ K, Na đến Al) chỉ có thể được điều chế bằng phương pháp nào sau đây?",
    options: [
      "Thủy luyện dùng kim loại mạnh đẩy kim loại yếu",
      "Nhiệt luyện dùng CO hoặc H₂ khử ở nhiệt độ cao",
      "Điện phân nóng chảy oxide hoặc muối chloride của chúng",
      "Điện phân dung dịch muối trong nước"
    ],
    correctIndex: 2,
    explanation: "Do ion kim loại từ K⁺ đến Al³⁺ có tính oxi hóa rất yếu, không bị khử trong dung dịch nước, bắt buộc phải dùng dòng điện một chiều cực mạnh trong phương pháp điện phân nóng chảy.",
    pageRef: 22
  },
  {
    id: 8,
    question: "Hợp kim nào của sắt có hàm lượng carbon từ 2% đến 5%, giòn và khó rèn nhưng chịu mài mòn tốt?",
    options: [
      "Thép cacbon mềm",
      "Gang",
      "Duralumin",
      "Đồng thau"
    ],
    correctIndex: 1,
    explanation: "Gang là hợp kim của Fe - C với hàm lượng carbon từ 2 - 5%, giòn và không thể rèn được; còn Thép có hàm lượng carbon dưới 2% dẻo và đàn hồi tốt hơn nhiều.",
    pageRef: 30
  }
];

export const ElectronQuiz: React.FC = () => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);

  const currentQ = QUIZ_QUESTIONS[currentIdx];

  const handleSelectOption = (idx: number) => {
    if (isAnswerSubmitted) return;
    setSelectedAnswer(idx);
    soundManager.playBubblePop();
  };

  const handleSubmitAnswer = () => {
    if (selectedAnswer === null) return;

    setIsAnswerSubmitted(true);
    const isCorrect = selectedAnswer === currentQ.correctIndex;

    if (isCorrect) {
      soundManager.playSuccess();
      setScore(prev => prev + 1);
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.7 }
      });
    } else {
      soundManager.playElectricZap();
    }
  };

  const handleNextQuestion = () => {
    if (currentIdx + 1 < QUIZ_QUESTIONS.length) {
      setCurrentIdx(prev => prev + 1);
      setSelectedAnswer(null);
      setIsAnswerSubmitted(false);
      soundManager.playBubblePop();
    } else {
      setIsCompleted(true);
      soundManager.playSuccess();
      confetti({
        particleCount: 150,
        spread: 100,
        origin: { y: 0.6 }
      });
    }
  };

  const handleRestartQuiz = () => {
    setCurrentIdx(0);
    setSelectedAnswer(null);
    setIsAnswerSubmitted(false);
    setScore(0);
    setIsCompleted(false);
    soundManager.playElectronChirp();
  };

  return (
    <section id="electron-quiz" className="relative py-14 sm:py-20 px-3.5 sm:px-6 lg:px-8 max-w-4xl mx-auto w-full overflow-hidden">
      {/* Quiz Section Header */}
      <div className="relative mb-8 sm:mb-12 text-center w-full">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-950/80 border border-amber-400/40 text-amber-300 text-[11px] sm:text-xs font-semibold uppercase tracking-wider mb-3">
          <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
          Đấu Trường Hóa Học Cùng Bé Electron
        </div>

        <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white mb-2 sm:mb-3">
          THỬ THÁCH <span className="bg-gradient-to-r from-amber-400 via-yellow-300 to-sky-400 bg-clip-text text-transparent">ĐẠI CƯƠNG KIM LOẠI</span>
        </h2>

        <p className="text-xs sm:text-base text-slate-300 font-light max-w-xl mx-auto">
          Bộ câu hỏi trắc nghiệm chọn lọc từ các chuyên đề trọng tâm của tạp chí Metal Core. Hãy xem bạn có thể đạt điểm tuyệt đối cùng Bé Electron không nhé!
        </p>
      </div>

      {!isCompleted ? (
        <div className="relative rounded-3xl bg-slate-900/90 border border-sky-500/40 p-4 sm:p-8 shadow-2xl backdrop-blur-xl w-full">
          {/* Progress bar */}
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2.5">
            <span className="font-semibold text-sky-400">Câu {currentIdx + 1} / {QUIZ_QUESTIONS.length}</span>
            <span className="font-mono bg-slate-800 px-2.5 py-0.5 rounded-md text-amber-300 font-bold">
              Điểm: {score}
            </span>
          </div>

          <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden mb-5 sm:mb-6">
            <div 
              className="h-full bg-gradient-to-r from-sky-500 to-cyan-400 transition-all duration-300 rounded-full"
              style={{ width: `${((currentIdx + 1) / QUIZ_QUESTIONS.length) * 100}%` }}
            />
          </div>

          {/* Question Text */}
          <div className="mb-5 sm:mb-6">
            <h3 className="text-base sm:text-xl font-bold text-white leading-relaxed">
              {currentQ.question}
            </h3>
            <div className="mt-2 text-xs text-sky-400 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 shrink-0" />
              <span>Gợi ý: Tìm trong Trang {currentQ.pageRef} tạp chí Metal Core</span>
            </div>
          </div>

          {/* Options */}
          <div className="space-y-2.5 sm:space-y-3 mb-5 sm:mb-6">
            {currentQ.options.map((opt, idx) => {
              let btnStyle = "bg-slate-800/50 border-slate-700 text-slate-200 hover:bg-slate-800 hover:border-slate-600";

              if (selectedAnswer === idx) {
                btnStyle = "bg-sky-950/80 border-sky-400 text-white shadow-md shadow-sky-500/20";
              }

              if (isAnswerSubmitted) {
                if (idx === currentQ.correctIndex) {
                  btnStyle = "bg-emerald-950/80 border-emerald-400 text-emerald-100 font-bold";
                } else if (selectedAnswer === idx) {
                  btnStyle = "bg-rose-950/80 border-rose-400 text-rose-100";
                } else {
                  btnStyle = "opacity-40 bg-slate-800/40 border-slate-800 text-slate-400";
                }
              }

              return (
                <button
                  key={idx}
                  disabled={isAnswerSubmitted}
                  onClick={() => handleSelectOption(idx)}
                  className={`w-full p-3 sm:p-4 rounded-2xl border text-left text-xs sm:text-sm font-medium transition-all flex items-center gap-3 cursor-pointer ${btnStyle}`}
                >
                  <span className="w-6 h-6 sm:w-7 sm:h-7 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center font-bold text-xs shrink-0">
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span className="flex-1 leading-snug">{opt}</span>
                  {isAnswerSubmitted && idx === currentQ.correctIndex && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  )}
                  {isAnswerSubmitted && selectedAnswer === idx && idx !== currentQ.correctIndex && (
                    <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Explanation Box */}
          {isAnswerSubmitted && (
            <div className={`p-3.5 sm:p-4 rounded-2xl border mb-5 animate-in fade-in duration-200 ${
              selectedAnswer === currentQ.correctIndex
                ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200'
                : 'bg-rose-950/30 border-rose-500/40 text-rose-200'
            }`}>
              <div className="flex items-center gap-2 mb-1 font-bold text-xs sm:text-sm">
                <span className="w-5 h-5 rounded-full bg-sky-400 text-slate-950 flex items-center justify-center text-[10px] font-bold shrink-0">
                  e⁻
                </span>
                <span>
                  {selectedAnswer === currentQ.correctIndex 
                    ? 'Chính xác! Bé Electron khen ngợi bạn!' 
                    : 'Chưa chính xác rồi, cùng xem lời giải nhé!'}
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed pl-7">
                {currentQ.explanation}
              </p>
            </div>
          )}

          {/* Quiz Action button */}
          <div className="flex justify-end">
            {!isAnswerSubmitted ? (
              <button
                disabled={selectedAnswer === null}
                onClick={handleSubmitAnswer}
                className="w-full sm:w-auto py-2.5 sm:py-3 px-6 rounded-2xl bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-400 hover:to-cyan-400 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-xs sm:text-sm shadow-lg shadow-sky-500/30 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <span>Kiểm tra đáp án</span>
                <Sparkles className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleNextQuestion}
                className="w-full sm:w-auto py-2.5 sm:py-3 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-500/30 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <span>{currentIdx + 1 === QUIZ_QUESTIONS.length ? 'Xem kết quả chung cuộc' : 'Câu hỏi tiếp theo'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      ) : (
        /* Final Certificate / Score Screen */
        <div className="relative rounded-3xl bg-slate-900 border border-amber-400/50 p-6 sm:p-10 shadow-2xl text-center w-full">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 text-slate-950 flex items-center justify-center mx-auto mb-3 sm:mb-4 shadow-xl shadow-amber-500/30 animate-bounce">
            <Trophy className="w-8 h-8 sm:w-10 sm:h-10" />
          </div>

          <h3 className="text-xl sm:text-3xl font-extrabold text-white mb-2">
            HOÀN THÀNH THỬ THÁCH METAL CORE!
          </h3>

          <p className="text-xs sm:text-sm text-slate-300 mb-5">
            Bé Electron xin chúc mừng bạn đã xuất sắc chinh phục trọn vẹn bộ câu hỏi!
          </p>

          <div className="inline-flex items-center gap-4 bg-slate-950/80 border border-slate-800 rounded-2xl px-5 sm:px-6 py-3 sm:py-4 mb-6">
            <div>
              <div className="text-2xl sm:text-3xl font-extrabold text-amber-400">
                {score} / {QUIZ_QUESTIONS.length}
              </div>
              <div className="text-[10px] sm:text-xs text-slate-400 font-medium mt-0.5">Số câu chính xác</div>
            </div>
            <div className="w-px h-8 sm:h-10 bg-slate-800" />
            <div>
              <div className="text-2xl sm:text-3xl font-extrabold text-sky-400">
                {Math.round((score / QUIZ_QUESTIONS.length) * 100)}%
              </div>
              <div className="text-[10px] sm:text-xs text-slate-400 font-medium mt-0.5">Độ chuẩn xác</div>
            </div>
          </div>

          <div className="p-3 sm:p-4 rounded-2xl bg-sky-950/40 border border-sky-800/60 max-w-md mx-auto mb-6 text-xs text-sky-200">
            {score === QUIZ_QUESTIONS.length ? (
              <p>🎉 Điểm tuyệt đối! Bạn nắm vững 100% kiến thức Đại cương kim loại 12. Tự tin 10 điểm Hóa học!</p>
            ) : score >= 6 ? (
              <p>👍 Rất tốt! Bạn đã nắm chắc nền tảng, hãy đọc thêm tạp chí Metal Core để bứt phá điểm số nhé!</p>
            ) : (
              <p>💡 Đừng lo! Hãy lật giở lại các trang trong tạp chí Metal Core và thử sức lại cùng Bé Electron nhé!</p>
            )}
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={handleRestartQuiz}
              className="w-full sm:w-auto py-2.5 sm:py-3 px-6 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs sm:text-sm transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Làm lại thử thách</span>
            </button>

            <a
              href="#flipbook-section"
              className="w-full sm:w-auto py-2.5 sm:py-3 px-6 rounded-2xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs sm:text-sm transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-sky-600/30"
            >
              <Award className="w-4 h-4" />
              <span>Xem lại Flipbook Tạp chí</span>
            </a>
          </div>
        </div>
      )}
    </section>
  );
};
