import React, { useState, useEffect, useRef } from 'react';
import { soundManager } from '../utils/soundFx';
import { 
  Zap, 
  Flame, 
  Hammer, 
  ShieldCheck, 
  Layers, 
  Atom, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle
} from 'lucide-react';

export const MagazineArticles: React.FC = () => {
  // Metallic Bond Simulator State
  const [hasVoltage, setHasVoltage] = useState(false);
  const [temperature, setTemperature] = useState(25); // Celsius
  const [isHammered, setIsHammered] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Electrochemical Series Reactivity Pair Tester
  const [selectedMetal, setSelectedMetal] = useState<string>('Zn');
  const [selectedSolution, setSelectedSolution] = useState<string>('CuSO4');

  // Interactive Metallic bond canvas animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animFrame: number;
    const width = canvas.width;
    const height = canvas.height;

    // Define cations in lattice
    const rows = 4;
    const cols = 8;
    const spacingX = width / (cols + 1);
    const spacingY = height / (rows + 1);

    // Electrons particles
    const electronCount = 45;
    const electrons = Array.from({ length: electronCount }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 1.5,
      vy: (Math.random() - 0.5) * 1.5,
      radius: 4
    }));

    let t = 0;

    const render = () => {
      t += 0.05;
      ctx.clearRect(0, 0, width, height);

      // Draw background electric field if voltage is on
      if (hasVoltage) {
        const gradient = ctx.createLinearGradient(0, 0, width, 0);
        gradient.addColorStop(0, 'rgba(239, 68, 68, 0.12)'); // Anode (+)
        gradient.addColorStop(1, 'rgba(56, 189, 248, 0.12)'); // Cathode (-)
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, width, height);

        ctx.fillStyle = '#ef4444';
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText('CỰC DƯƠNG (+)', 15, 25);

        ctx.fillStyle = '#38bdf8';
        ctx.fillText('CỰC ÂM (-)', width - 95, 25);
      }

      // Thermal vibration factor
      const vibrationAmp = (temperature / 100) * 3;

      // Draw Metal Cations (Mⁿ⁺)
      for (let r = 0; r < rows; r++) {
        // If hammered, top 2 rows slip to the right without breaking
        const shiftX = isHammered && r < 2 ? 35 : 0;

        for (let c = 0; c < cols; c++) {
          const baseX = (c + 1) * spacingX + shiftX;
          const baseY = (r + 1) * spacingY;
          const vibX = Math.sin(t * 3 + r * cols + c) * vibrationAmp;
          const vibY = Math.cos(t * 3 + r * cols + c) * vibrationAmp;

          const cx = baseX + vibX;
          const cy = baseY + vibY;

          // Cation Glow
          const radGrad = ctx.createRadialGradient(cx, cy, 2, cx, cy, 18);
          radGrad.addColorStop(0, '#fbbf24');
          radGrad.addColorStop(0.7, '#d97706');
          radGrad.addColorStop(1, 'rgba(180, 83, 9, 0)');
          ctx.fillStyle = radGrad;
          ctx.beginPath();
          ctx.arc(cx, cy, 18, 0, Math.PI * 2);
          ctx.fill();

          // Cation Core
          ctx.fillStyle = '#f59e0b';
          ctx.beginPath();
          ctx.arc(cx, cy, 12, 0, Math.PI * 2);
          ctx.fill();

          // Text M+
          ctx.fillStyle = '#78350f';
          ctx.font = 'bold 10px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('Fe²⁺', cx, cy);
        }
      }

      // Draw & Update Free Delocalized Electrons
      electrons.forEach((e) => {
        // Voltage drift force
        if (hasVoltage) {
          e.vx -= 0.09; // Drift towards positive anode on left
        } else {
          // Normal thermal wander
          e.vx += (Math.random() - 0.5) * 0.2;
          e.vy += (Math.random() - 0.5) * 0.2;
        }

        // Clamp speed
        const maxV = 2.5 + (temperature / 100);
        e.vx = Math.max(-maxV, Math.min(maxV, e.vx));
        e.vy = Math.max(-maxV, Math.min(maxV, e.vy));

        e.x += e.vx;
        e.y += e.vy;

        // Wrap around borders
        if (e.x < 0) e.x = width;
        if (e.x > width) e.x = 0;
        if (e.y < 0) e.y = height;
        if (e.y > height) e.y = 0;

        // Electron glow
        ctx.fillStyle = 'rgba(56, 189, 248, 0.45)';
        ctx.beginPath();
        ctx.arc(e.x, e.y, 7, 0, Math.PI * 2);
        ctx.fill();

        // Electron core
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.arc(e.x, e.y, 3, 0, Math.PI * 2);
        ctx.fill();
      });

      animFrame = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animFrame);
    };
  }, [hasVoltage, temperature, isHammered]);

  // Alpha rule evaluation
  const METALS_ORDER = ['K', 'Na', 'Mg', 'Al', 'Zn', 'Fe', 'Ni', 'Sn', 'Pb', 'H', 'Cu', 'Ag', 'Au'];
  
  const getReactionResult = () => {
    const solutionMetal = selectedSolution === 'CuSO4' ? 'Cu' : selectedSolution === 'AgNO3' ? 'Ag' : selectedSolution === 'FeSO4' ? 'Fe' : 'Zn';
    const metalIdx = METALS_ORDER.indexOf(selectedMetal);
    const solIdx = METALS_ORDER.indexOf(solutionMetal);

    if (metalIdx === -1 || solIdx === -1) return { reacts: false, explanation: "Không xác định" };

    if (metalIdx < solIdx) {
      return {
        reacts: true,
        equation: `${selectedMetal} + ${selectedSolution} → Có phản ứng sinh ra ${solutionMetal}!`,
        explanation: `Kim loại ${selectedMetal} có tính khử mạnh hơn ${solutionMetal}, đẩy được ${solutionMetal} ra khỏi dung dịch muối theo quy tắc alpha (α).`
      };
    } else if (metalIdx === solIdx) {
      return {
        reacts: false,
        equation: `Không xảy ra phản ứng trao đổi`,
        explanation: `Cùng là kim loại ${selectedMetal}, không xảy ra phản ứng khử đẩy kim loại.`
      };
    } else {
      return {
        reacts: false,
        equation: `Không xảy ra phản ứng`,
        explanation: `Kim loại ${selectedMetal} có tính khử yếu hơn ${solutionMetal}, không thể đẩy ${solutionMetal} ra khỏi muối.`
      };
    }
  };

  const reaction = getReactionResult();

  return (
    <section id="magazine-articles" className="relative py-14 sm:py-20 px-3.5 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full overflow-hidden">
      {/* Magazine Topic Header */}
      <div className="relative mb-10 sm:mb-14 text-center max-w-3xl mx-auto w-full">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-950/80 border border-blue-400/40 text-sky-300 text-[11px] sm:text-xs font-semibold uppercase tracking-wider mb-3">
          <Atom className="w-3.5 h-3.5 text-sky-400" />
          Chuyên Khảo Khoa Học Trọng Tâm
        </div>
        <h2 className="text-2xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white mb-3 sm:mb-4">
          BÍ MẬT <span className="bg-gradient-to-r from-sky-400 via-teal-300 to-indigo-400 bg-clip-text text-transparent">LIÊN KẾT & TÍNH CHẤT KIM LOẠI</span>
        </h2>
        <p className="text-xs sm:text-base text-slate-300 font-light leading-relaxed">
          Tìm hiểu bản chất vật lý và hóa học sâu sắc từ các trang 6 - 35 của tạp chí Metal Core: mô hình biển electron, tính dẻo, dẫn điện, quy tắc alpha và giải pháp bảo vệ vỏ tàu vượt đại dương.
        </p>
      </div>

      {/* Feature 1: Interactive Metallic Bond Model Simulator */}
      <div className="mb-10 sm:mb-14 rounded-3xl bg-slate-900/80 border border-sky-500/30 p-4 sm:p-8 shadow-2xl relative overflow-hidden w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 items-center w-full">
          {/* Simulator Canvas */}
          <div className="lg:col-span-7 flex flex-col items-center w-full">
            <div className="relative w-full aspect-[16/10] bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-inner flex items-center justify-center">
              <canvas
                ref={canvasRef}
                width={640}
                height={400}
                className="w-full h-full object-contain"
              />

              {/* Status badges */}
              <div className="absolute bottom-2 sm:bottom-3 left-2 sm:left-3 bg-slate-900/90 backdrop-blur-md px-2.5 py-1 rounded-lg border border-slate-800 text-[10px] sm:text-[11px] text-slate-300 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                <span>Cation Fe²⁺</span>
                <span className="w-2 h-2 rounded-full bg-sky-400 ml-1.5" />
                <span>Electron e⁻ tự do</span>
              </div>
            </div>

            {/* Interactive Control Knobs */}
            <div className="w-full mt-3.5 grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* Voltage switch */}
              <button
                onClick={() => {
                  setHasVoltage(!hasVoltage);
                  soundManager.playElectricZap();
                }}
                className={`p-2.5 sm:p-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  hasVoltage
                    ? 'bg-sky-500 text-white border-sky-400 shadow-lg shadow-sky-500/30'
                    : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-800'
                }`}
              >
                <Zap className="w-4 h-4 text-amber-300" />
                <span className="text-center">{hasVoltage ? 'Đang cấp điện: e⁻ dịch chuyển!' : 'Bật điện áp (+ / -)'}</span>
              </button>

              {/* Hammer strike (ductility) */}
              <button
                onClick={() => {
                  setIsHammered(!isHammered);
                  soundManager.playBubblePop();
                }}
                className={`p-2.5 sm:p-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  isHammered
                    ? 'bg-amber-600 text-white border-amber-400 shadow-lg shadow-amber-500/30'
                    : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-800'
                }`}
              >
                <Hammer className="w-4 h-4 text-yellow-300" />
                <span>{isHammered ? 'Trượt lớp tinh thể (Dẻo)' : 'Đập búa (Tính dẻo)'}</span>
              </button>

              {/* Temperature slider */}
              <div className="p-2.5 rounded-2xl bg-slate-800/80 border border-slate-700 flex flex-col justify-center">
                <div className="flex items-center justify-between text-[11px] text-slate-300 font-semibold mb-1">
                  <span className="flex items-center gap-1">
                    <Flame className="w-3.5 h-3.5 text-rose-400" />
                    Nhiệt độ:
                  </span>
                  <span className="text-amber-400 font-mono">{temperature}°C</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="120"
                  value={temperature}
                  onChange={(e) => setTemperature(Number(e.target.value))}
                  className="w-full accent-sky-400 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Theoretical explanation from flipbook */}
          <div className="lg:col-span-5 space-y-3 sm:space-y-4 w-full">
            <div className="inline-flex items-center gap-1.5 text-xs text-sky-400 font-bold uppercase tracking-wider bg-sky-950/80 px-2.5 py-1 rounded-full border border-sky-800">
              <Atom className="w-3.5 h-3.5" />
              Tạp chí Metal Core • Trang 6 - 8
            </div>

            <h3 className="text-xl sm:text-2xl font-bold text-white leading-snug">
              Mô Hình "Biển Electron" & Bản Chất Liên Kết Kim Loại
            </h3>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Liên kết kim loại được hình thành từ <strong>lực hút tĩnh điện</strong> giữa các cation dương kim loại nằm ở nút mạng tinh thể và các <strong>electron hóa trị tự do</strong> chuyển động hỗn loạn xung quanh.
            </p>

            <div className="space-y-2.5 pt-1">
              <div className="p-3 sm:p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-start gap-2.5">
                <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0 font-bold text-xs">
                  1
                </div>
                <div>
                  <h4 className="font-bold text-xs sm:text-sm text-white">Vì sao kim loại có tính dẻo?</h4>
                  <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5">
                    Khi chịu ngoại lực, các lớp ion trượt lên nhau nhưng không bị phá vỡ vì biển electron tự do đóng vai trò như "chất keo" liên tục liên kết chúng lại.
                  </p>
                </div>
              </div>

              <div className="p-3 sm:p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-start gap-2.5">
                <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 font-bold text-xs">
                  2
                </div>
                <div>
                  <h4 className="font-bold text-xs sm:text-sm text-white">Dẫn điện & Dẫn nhiệt siêu đẳng</h4>
                  <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5">
                    Dưới hiệu điện thế, electron tự do bị hút dồn về cực dương tạo thành dòng điện. Khi đốt nóng, electron chuyển động nhanh hơn và va chạm truyền động năng cho toàn khối.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Feature 2: Chemical Series & Alpha Rule Interactive Tester */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8 mb-10 sm:mb-14 w-full">
        {/* Electrochemical Alpha Tester */}
        <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-4 sm:p-6 lg:p-8 flex flex-col justify-between shadow-xl w-full">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] sm:text-xs font-bold uppercase tracking-wider text-amber-400 bg-amber-950/80 px-2.5 py-1 rounded-full border border-amber-800/60">
                Thí Nghiệm Quy Tắc Alpha (α)
              </span>
              <span className="text-xs text-slate-400 font-mono">Trang 17 Tạp chí</span>
            </div>

            <h3 className="text-lg sm:text-2xl font-bold text-white mb-2">
              Kim Loại Đẩy Kim Loại Ra Khỏi Muối
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 mb-5">
              Chọn kim loại nhúng và dung dịch muối để Bé Electron kiểm tra xem phản ứng oxi hóa - khử có xảy ra tự phát hay không!
            </p>

            {/* Selectors */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5">
              <div>
                <label className="text-xs font-semibold text-slate-300 mb-1 block">Thanh Kim Loại:</label>
                <select
                  value={selectedMetal}
                  onChange={(e) => {
                    setSelectedMetal(e.target.value);
                    soundManager.playBubblePop();
                  }}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-sky-400 cursor-pointer"
                >
                  <option value="Mg">Magie (Mg)</option>
                  <option value="Al">Nhôm (Al)</option>
                  <option value="Zn">Kẽm (Zn)</option>
                  <option value="Fe">Sắt (Fe)</option>
                  <option value="Cu">Đồng (Cu)</option>
                  <option value="Ag">Bạc (Ag)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 mb-1 block">Dung Dịch Muối:</label>
                <select
                  value={selectedSolution}
                  onChange={(e) => {
                    setSelectedSolution(e.target.value);
                    soundManager.playBubblePop();
                  }}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-sky-400 cursor-pointer"
                >
                  <option value="CuSO4">Dung dịch CuSO₄ (muối Cu²⁺)</option>
                  <option value="AgNO3">Dung dịch AgNO₃ (muối Ag⁺)</option>
                  <option value="FeSO4">Dung dịch FeSO₄ (muối Fe²⁺)</option>
                  <option value="ZnSO4">Dung dịch ZnSO₄ (muối Zn²⁺)</option>
                </select>
              </div>
            </div>

            {/* Reaction Outcome Card */}
            <div className={`p-3.5 rounded-2xl border ${
              reaction.reacts 
                ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200' 
                : 'bg-rose-950/30 border-rose-500/40 text-rose-200'
            }`}>
              <div className="flex items-center gap-2 mb-1.5 font-bold text-xs sm:text-sm">
                {reaction.reacts ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="text-emerald-300">PHẢN ỨNG XẢY RA!</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span className="text-rose-300">KHÔNG XẢY RA PHẢN ỨNG</span>
                  </>
                )}
              </div>
              <p className="font-mono text-xs font-bold mb-1 text-white">{reaction.equation}</p>
              <p className="text-xs text-slate-300 leading-relaxed">{reaction.explanation}</p>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-[10px] sm:text-[11px] text-slate-400 flex items-center justify-between">
            <span className="truncate">K &gt; Na &gt; Mg &gt; Al &gt; Zn &gt; Fe &gt; Cu &gt; Ag &gt; Au</span>
            <span className="text-sky-400 font-semibold shrink-0 ml-2">Quy tắc α</span>
          </div>
        </div>

        {/* Cathodic Protection / Save The Ship Theory */}
        <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-4 sm:p-6 lg:p-8 flex flex-col justify-between shadow-xl w-full">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] sm:text-xs font-bold uppercase tracking-wider text-sky-400 bg-sky-950/80 px-2.5 py-1 rounded-full border border-sky-800/60">
                Chống Ăn Mòn Tàu Biển
              </span>
              <span className="text-xs text-slate-400 font-mono">Trang 34 - 36 Tạp chí</span>
            </div>

            <h3 className="text-lg sm:text-2xl font-bold text-white mb-2">
              Phương Pháp Điện Hóa: Kẽm (Zn) Hi Sinh
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 mb-4 leading-relaxed">
              Vỏ tàu thép (Fe) ngâm trong nước biển tạo thành pin điện hóa khổng lồ. Nếu không có biện pháp bảo vệ, sắt sẽ bị oxy hóa thành gỉ sét Fe₂O₃ và làm đắm tàu!
            </p>

            <div className="space-y-2.5">
              <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-start gap-2.5">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-white">Cơ chế bảo vệ Catot (Cathodic Protection)</h4>
                  <p className="text-[11px] text-slate-300 mt-0.5 leading-snug">
                    Người ta gắn các khối kim loại <strong>Kẽm (Zn)</strong> vào vỏ tàu ngập dưới nước. Vì Zn có tính khử mạnh hơn Fe, Zn sẽ đóng vai trò Anot bị ăn mòn trước: <code className="text-sky-300">Zn → Zn²⁺ + 2e⁻</code>. Vỏ tàu sắt đóng vai trò Catot được bảo toàn!
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-start gap-2.5">
                <Layers className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-white">Bảo vệ bề mặt truyền thống</h4>
                  <p className="text-[11px] text-slate-300 mt-0.5 leading-snug">
                    Sơn chống hà, quét dầu mỡ, tráng kẽm (tôn lợp mái nhà) hoặc mạ crom ngăn không cho kim loại tiếp xúc trực tiếp với không khí ẩm và nước.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-400">Muốn chơi thử cơ chế này?</span>
            <a
              href="#interactive-stations"
              className="text-xs font-bold text-sky-400 hover:text-sky-300 flex items-center gap-1"
            >
              Vào game "Save The Ship" <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>

      {/* Quick Scientific Trivia Banners */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 w-full">
        {[
          { label: 'Dẫn điện tốt nhất', value: 'Bạc (Ag)', note: 'Ag > Cu > Au > Al > Fe', color: 'text-slate-100' },
          { label: 'Nhiệt độ nóng chảy cao nhất', value: 'Wolfram (W)', note: '3410 °C làm dây tóc', color: 'text-amber-400' },
          { label: 'Kim loại nhẹ nhất', value: 'Liti (Li)', note: 'd = 0.53 g/cm³ nổi trên nước', color: 'text-sky-400' },
          { label: 'Kim loại cứng nhất', value: 'Crom (Cr)', note: 'Độ cứng 9/10, rạch được kính', color: 'text-teal-400' }
        ].map((item, i) => (
          <div key={i} className="p-3.5 rounded-2xl bg-slate-900/70 border border-slate-800/80 text-center hover:border-sky-500/40 transition-colors">
            <span className="text-[10px] sm:text-[11px] uppercase tracking-wider text-slate-400 block mb-1">{item.label}</span>
            <div className={`text-base sm:text-xl font-extrabold ${item.color}`}>{item.value}</div>
            <span className="text-[10px] sm:text-[11px] text-slate-500 font-mono mt-0.5 block">{item.note}</span>
          </div>
        ))}
      </div>
    </section>
  );
};
