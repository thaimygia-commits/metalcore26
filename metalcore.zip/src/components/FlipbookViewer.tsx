import React, { useState, useRef } from 'react';
import { 
  BookOpen, 
  Maximize, 
  ExternalLink, 
  RotateCcw, 
  Bookmark, 
  Award, 
  Users, 
  Sparkles,
  Info,
  ChevronRight,
  Eye
} from 'lucide-react';
import { soundManager } from '../utils/soundFx';

interface ChapterJump {
  title: string;
  page: number;
  chapter: string;
  desc: string;
  tag: string;
}

const CHAPTERS: ChapterJump[] = [
  { chapter: "Bìa", page: 1, title: "Metal Core - Đại Cương Kim Loại", desc: "Trang bìa tạp chí & lời mở đầu hành trình của bé Electron", tag: "Cover" },
  { chapter: "Mục Lục", page: 4, title: "Mục Lục & Bản Đồ Kiến Thức", desc: "Tổng quan 6 chuyên đề đại cương kim loại 12", tag: "Index" },
  { chapter: "Chương I", page: 6, title: "Cấu Tạo & Liên Kết Kim Loại", desc: "Mô hình biển electron, mạng tinh thể lập phương, lục phương", tag: "Liên kết" },
  { chapter: "Chương II", page: 10, title: "Tính Chất Vật Lý & Hóa Học", desc: "Dẫn điện Ag>Cu>Au>Al>Fe, dẻo, thụ động hóa Fe, Al, Cr", tag: "Tính chất" },
  { chapter: "Chương III", page: 20, title: "Kim Loại Trong Tự Nhiên & Tách Kim Loại", desc: "Điện phân nóng chảy, nhiệt luyện, thủy luyện, tái chế xanh", tag: "Điều chế" },
  { chapter: "Chương IV", page: 27, title: "Thế Giới Hợp Kim Kì Diệu", desc: "Gang, thép, duralumin, hợp kim nhớ hình và ứng dụng", tag: "Hợp kim" },
  { chapter: "Chương V", page: 33, title: "Sự Ăn Mòn Kim Loại & Bảo Vệ", desc: "Ăn mòn hóa học & điện hóa, gắn kẽm Zn bảo vệ vỏ tàu biển", tag: "Ăn mòn" },
  { chapter: "Chương VI", page: 37, title: "Ôn Tập Toàn Diện & Đề Thi Thử", desc: "Hệ thống kiến thức, câu hỏi trắc nghiệm & thử thách", tag: "Ôn tập" },
];

export const FlipbookViewer: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [key, setKey] = useState<number>(0);
  const [copied, setCopied] = useState<boolean>(false);
  const iframeContainerRef = useRef<HTMLDivElement>(null);

  const flipbookBaseUrl = "https://heyzine.com/flip-book/0403fd6e29.html";
  const currentIframeSrc = `${flipbookBaseUrl}#page/${currentPage}`;

  const handleJumpToPage = (pageNum: number) => {
    soundManager.playBubblePop();
    setCurrentPage(pageNum);
    setKey(prev => prev + 1);
  };

  const handleReload = () => {
    soundManager.playBubblePop();
    setKey(prev => prev + 1);
  };

  const toggleFullscreen = () => {
    if (!iframeContainerRef.current) return;

    if (!document.fullscreenElement) {
      iframeContainerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const copyShareLink = () => {
    navigator.clipboard.writeText(flipbookBaseUrl);
    setCopied(true);
    soundManager.playSuccess();
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <section id="flipbook-section" className="relative py-12 sm:py-16 px-3.5 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full overflow-hidden">
      {/* Background glow effects strictly constrained */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-full max-w-4xl h-[300px] bg-gradient-to-r from-sky-500/15 via-cyan-400/15 to-indigo-500/15 blur-3xl pointer-events-none rounded-full" />

      {/* Magazine Editorial Header */}
      <div className="relative mb-8 sm:mb-10 text-center max-w-3xl mx-auto w-full">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-sky-950/80 border border-sky-400/40 text-sky-300 text-[11px] sm:text-xs font-semibold uppercase tracking-wider mb-3 shadow-inner">
          <BookOpen className="w-3.5 h-3.5 text-sky-400" />
          Tạp Chí Điện Tử Khoa Học Số Độc Quyền
        </div>

        <h2 className="text-2xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white mb-3 sm:mb-4">
          METAL CORE <span className="bg-gradient-to-r from-sky-400 via-cyan-300 to-blue-400 bg-clip-text text-transparent">ĐẠI CƯƠNG KIM LOẠI</span>
        </h2>

        <p className="text-xs sm:text-base text-slate-300 font-light leading-relaxed">
          Tạp chí số 40 trang chuyên sâu dành cho học sinh THPT Hóa Học 12. Tích hợp hiệu ứng lật trang 3D chân thực, sơ đồ tư duy minh họa và liên kết trực tiếp tới các trạm trò chơi khoa học tương tác.
        </p>

        {/* Authors & Publication credits */}
        <div className="mt-5 flex flex-wrap items-center justify-center gap-3 sm:gap-6 text-[11px] sm:text-xs text-slate-400 border-y border-slate-800/80 py-2.5">
          <div className="flex items-center gap-1.5">
            <Users className="w-4 h-4 text-sky-400" />
            <span className="text-slate-200 font-semibold">Tác giả:</span> Nhóm 06 – 12A2 (Năm học 2026 - 2027)
          </div>
          <div className="flex items-center gap-1.5">
            <Award className="w-4 h-4 text-amber-400" />
            <span className="text-slate-200 font-semibold">Thực hiện:</span> Mỹ Gia, Tường Ngân, Ngọc Như, Hải Nhi, Thị Minh
          </div>
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-200 font-semibold">Quy mô:</span> 40 Trang Full HD
          </div>
        </div>
      </div>

      {/* Main Flipbook Showcase Container */}
      <div 
        ref={iframeContainerRef}
        className={`relative rounded-2xl sm:rounded-3xl overflow-hidden border border-sky-500/40 bg-slate-950 shadow-2xl transition-all w-full ${
          isFullscreen ? 'p-0 w-screen h-screen rounded-none' : 'p-2 sm:p-4'
        }`}
      >
        {/* Top Control Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 sm:p-3 bg-slate-900/90 border-b border-slate-800 rounded-xl sm:rounded-2xl mb-2 sm:mb-4">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
            </div>
            <div className="flex items-center gap-1.5 pl-2 border-l border-slate-800 text-[11px] sm:text-xs text-slate-300">
              <span className="font-semibold text-white">Heyzine Reader v3</span>
              <span className="text-slate-500 hidden sm:inline">|</span>
              <span className="text-sky-400 font-medium">Trang {currentPage}/40</span>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleReload}
              className="p-1.5 sm:px-2.5 sm:py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer text-xs flex items-center gap-1"
              title="Tải lại trang Flipbook"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Tải lại</span>
            </button>

            <button
              onClick={copyShareLink}
              className="px-2.5 py-1.5 sm:py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer text-xs flex items-center gap-1"
              title="Sao chép liên kết"
            >
              <Bookmark className="w-3.5 h-3.5 text-sky-400" />
              <span>{copied ? 'Đã chép!' : 'Chia sẻ'}</span>
            </button>

            <button
              onClick={toggleFullscreen}
              className="px-2.5 py-1.5 sm:py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-medium transition-colors cursor-pointer text-xs flex items-center gap-1 shadow-md shadow-sky-600/30"
              title="Phóng to toàn màn hình"
            >
              <Maximize className="w-3.5 h-3.5" />
              <span>{isFullscreen ? 'Thu nhỏ' : 'Toàn màn hình'}</span>
            </button>

            <a
              href={flipbookBaseUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-1.5 sm:p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer text-xs flex items-center"
              title="Mở trực tiếp trên trang Heyzine"
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Embedded Iframe - High quality responsive viewport */}
        <div className="relative w-full aspect-[4/3] sm:aspect-[16/10] md:aspect-[16/9] min-h-[380px] sm:min-h-[480px] md:min-h-[560px] bg-slate-900 rounded-xl sm:rounded-2xl overflow-hidden border border-slate-800">
          <iframe
            key={key}
            src={currentIframeSrc}
            title="Metal Core - Đại Cương Kim Loại Flipbook"
            className="w-full h-full border-0"
            allow="fullscreen; clipboard-write"
            loading="lazy"
          />
        </div>

        {/* Reading Tip footer */}
        <div className="mt-2.5 px-3 py-2 bg-slate-900/70 rounded-xl flex items-center justify-between text-[11px] sm:text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Info className="w-3.5 h-3.5 text-sky-400 shrink-0" />
            <span>Mẹo: Nhấp chuột hoặc vuốt mép trang để lật 3D, cuộn chuột để zoom to rõ!</span>
          </div>
          <div className="hidden sm:flex items-center gap-1.5 text-sky-400 font-medium">
            <Eye className="w-3.5 h-3.5" />
            <span>Chế độ Tạp chí tương tác 40 trang</span>
          </div>
        </div>
      </div>

      {/* Fast Chapter Navigation Grid */}
      <div className="mt-8 sm:mt-10">
        <div className="mb-4">
          <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-sky-400" />
            Mục lục nhanh & Chuyển trang tức thì
          </h3>
          <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5">Nhấp vào từng chuyên mục để lật thẳng tới trang nội dung tương ứng trong flipbook</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3.5">
          {CHAPTERS.map((chap, idx) => (
            <button
              key={idx}
              onClick={() => handleJumpToPage(chap.page)}
              className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer group hover:-translate-y-0.5 ${
                currentPage === chap.page
                  ? 'bg-sky-950/80 border-sky-400 shadow-lg shadow-sky-500/20'
                  : 'bg-slate-900/70 border-slate-800 hover:border-sky-500/50 hover:bg-slate-800/70'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-sky-400 bg-sky-950 px-2 py-0.5 rounded border border-sky-800/60">
                  {chap.chapter}
                </span>
                <span className="text-[11px] font-mono text-slate-400 font-semibold">Trang {chap.page}</span>
              </div>
              <h4 className="font-bold text-xs sm:text-sm text-white group-hover:text-sky-300 transition-colors line-clamp-1">
                {chap.title}
              </h4>
              <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                {chap.desc}
              </p>
              <div className="mt-2.5 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[10px] sm:text-[11px] text-sky-400 group-hover:text-sky-300">
                <span className="text-slate-500 font-medium">{chap.tag}</span>
                <span className="flex items-center gap-0.5 font-semibold">
                  Lật trang <ChevronRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
