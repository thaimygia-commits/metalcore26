import React from 'react';
import { BookOpen, Gamepad2, Sparkles, ArrowRight, Award } from 'lucide-react';
import { soundManager } from '../utils/soundFx';
import { ElectronMascotArtwork } from './ElectronMascotArtwork';

export const HeroSection: React.FC = () => {
  const handleScrollTo = (id: string) => {
    soundManager.playBubblePop();
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative pt-24 sm:pt-32 pb-14 sm:pb-20 px-3.5 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full overflow-hidden">
      {/* Background radial gradients constrained within container */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-full max-w-3xl h-[350px] bg-gradient-to-b from-sky-500/20 via-cyan-400/10 to-transparent blur-[100px] pointer-events-none rounded-full" />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center w-full">
        {/* Left Column: Editorial Headline & Meta */}
        <div className="lg:col-span-7 space-y-4 sm:space-y-6 text-center lg:text-left w-full">
          {/* Issue Tag */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-sky-950/90 border border-sky-400/40 text-sky-300 text-[11px] sm:text-xs font-semibold uppercase tracking-wider shadow-lg max-w-full">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping shrink-0" />
            <span className="truncate">Tạp Chí Khoa Học Số Chuyên Đề Hóa 12 • Nhóm 06 - 12A2</span>
          </div>

          {/* Main Title */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-tight">
            METAL <span className="bg-gradient-to-r from-sky-400 via-cyan-300 to-indigo-300 bg-clip-text text-transparent">CORE</span>
            <span className="block text-xl sm:text-3xl lg:text-4xl font-extrabold text-slate-100 mt-1 sm:mt-2 tracking-normal">
              ĐẠI CƯƠNG VỀ KIM LOẠI
            </span>
          </h1>

          {/* Slogan from Flipbook */}
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-1.5 sm:gap-2 text-xs sm:text-sm font-medium text-cyan-300">
            <span className="px-2.5 py-1 rounded-full bg-slate-900/80 border border-slate-800">Bộ lõi kiến thức</span>
            <span className="text-slate-500">•</span>
            <span className="px-2.5 py-1 rounded-full bg-slate-900/80 border border-slate-800">Nắm trọn lý thuyết</span>
            <span className="text-slate-500">•</span>
            <span className="px-2.5 py-1 rounded-full bg-slate-900/80 border border-slate-800">Gắn liền thực tế</span>
          </div>

          {/* Description */}
          <p className="text-xs sm:text-sm md:text-base text-slate-300 font-light leading-relaxed max-w-2xl mx-auto lg:mx-0">
            Chào mừng bạn đến với tạp chí số <strong>Metal Core</strong>! Cùng <strong>Bé Electron</strong> khám phá mạng tinh thể kim loại, mô hình biển electron, giải cứu tàu biển trong <em>Save The Ship</em> và giải mã các phòng thí nghiệm bí ẩn sống động!
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 pt-2 w-full">
            <button
              onClick={() => handleScrollTo('flipbook-section')}
              className="w-full sm:w-auto py-3 sm:py-3.5 px-6 rounded-2xl bg-gradient-to-r from-sky-500 via-cyan-500 to-blue-600 hover:from-sky-400 hover:to-cyan-400 text-white font-bold text-xs sm:text-sm shadow-xl shadow-sky-500/30 transition-all hover:scale-105 cursor-pointer flex items-center justify-center gap-2"
            >
              <BookOpen className="w-4 h-4" />
              <span>Đọc Flipbook Ngay (40 Trang)</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => handleScrollTo('interactive-stations')}
              className="w-full sm:w-auto py-3 sm:py-3.5 px-6 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-sky-400 text-slate-200 font-bold text-xs sm:text-sm transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md"
            >
              <Gamepad2 className="w-4 h-4 text-cyan-400" />
              <span>6 Trạm Mini-Apps & Games</span>
            </button>
          </div>

          {/* Authors acknowledgment banner */}
          <div className="p-3 sm:p-4 rounded-2xl bg-slate-900/70 border border-slate-800/80 text-[11px] sm:text-xs text-slate-400 text-left">
            <div className="flex items-center gap-2 text-sky-400 font-semibold mb-1">
              <Award className="w-4 h-4 shrink-0" />
              <span>Dự Án Nghiên Cứu & Thiết Kế Bởi Nhóm Học Sinh 12A2 (Năm học 2026 - 2027):</span>
            </div>
            <p className="text-slate-200 font-medium">
              Thái Mỹ Gia • Bành Lâm Tường Ngân • Nguyễn Huỳnh Ngọc Như • Nguyễn Hồ Hải Nhi • Nguyễn Thị Minh
            </p>
          </div>
        </div>

        {/* Right Column: Hero Visual Graphic with Bé Electron */}
        <div className="lg:col-span-5 relative flex items-center justify-center w-full">
          {/* Decorative card */}
          <div className="relative w-full max-w-md rounded-3xl bg-slate-900/90 border border-sky-500/40 p-4 sm:p-6 shadow-2xl backdrop-blur-xl">
            {/* Magazine Cover Preview / Graphic */}
            <div className="relative w-full aspect-[4/3] rounded-2xl overflow-hidden border border-slate-800 shadow-inner group">
              <img
                src="/images/metal-core-banner.jpg"
                alt="Metal Core Magazine Visual"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-transparent" />
              
              <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white">
                <div>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-sky-400">Special Issue</span>
                  <div className="font-extrabold text-sm sm:text-base">METAL CORE MAGAZINE</div>
                </div>
                <div className="px-2.5 py-1 rounded-lg bg-sky-500/80 text-white font-bold text-xs backdrop-blur-md">
                  40 Trang HD
                </div>
              </div>
            </div>

            {/* Mascot floating mini-intro card featuring Bé Electron */}
            <div className="mt-4 p-3 sm:p-4 rounded-2xl bg-sky-950/70 border border-sky-500/40 flex items-center gap-3 sm:gap-4">
              <div className="relative w-16 h-16 sm:w-20 sm:h-20 shrink-0 animate-electron-float">
                <ElectronMascotArtwork idPrefix="hero_mascot" emotion="happy" className="w-full h-full" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 text-xs font-bold text-sky-300">
                  <Sparkles className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                  <span className="truncate">Bé Electron sẵn sàng đồng hành!</span>
                </div>
                <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                  "Chạm vào tớ ở góc màn hình hoặc kéo tớ bay khắp nơi để nghe mẹo thi và giải thích hóa học nha!"
                </p>
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="mt-3 grid grid-cols-3 gap-2 text-center pt-2 border-t border-slate-800/80">
              <div>
                <div className="font-extrabold text-sm sm:text-base text-white">40</div>
                <div className="text-[10px] text-slate-400">Trang Tạp Chí</div>
              </div>
              <div>
                <div className="font-extrabold text-sm sm:text-base text-cyan-400">6</div>
                <div className="text-[10px] text-slate-400">Trạm Mini-Apps</div>
              </div>
              <div>
                <div className="font-extrabold text-sm sm:text-base text-amber-400">100%</div>
                <div className="text-[10px] text-slate-400">Chuẩn Hóa 12</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
