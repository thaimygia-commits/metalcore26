import React, { useId } from 'react';
import { EmotionType } from '../types';

interface ElectronMascotArtworkProps {
  emotion?: EmotionType;
  className?: string;
  isWaving?: boolean;
  isBlinking?: boolean;
  idPrefix?: string;
}

export const ElectronMascotArtwork: React.FC<ElectronMascotArtworkProps> = ({
  emotion = 'happy',
  className = 'w-full h-full',
  isWaving = true,
  isBlinking = false,
  idPrefix,
}) => {
  const generatedId = useId().replace(/:/g, '');
  const prefix = idPrefix || `mascot_${generatedId}`;

  const bodyGradientId = `${prefix}_bodyGradient`;
  const badgeGradientId = `${prefix}_badgeGradient`;
  const gaugeGradId = `${prefix}_gaugeGrad`;
  const specularHighlightId = `${prefix}_specularHighlight`;

  return (
    <svg
      viewBox="0 0 280 320"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`${className} overflow-visible`}
      style={{
        transform: 'translateZ(0)',
        willChange: 'transform',
        backfaceVisibility: 'hidden',
      }}
    >
      <defs>
        {/* Body Main Sphere Gradient */}
        <radialGradient id={bodyGradientId} cx="35%" cy="30%" r="75%">
          <stop offset="0%" stopColor="#e0f7fe" />
          <stop offset="25%" stopColor="#bae6fd" />
          <stop offset="65%" stopColor="#7dd3fc" />
          <stop offset="90%" stopColor="#38bdf8" />
          <stop offset="100%" stopColor="#0284c7" />
        </radialGradient>

        {/* Chest Medallion Gradient */}
        <radialGradient id={badgeGradientId} cx="40%" cy="40%" r="60%">
          <stop offset="0%" stopColor="#1e293b" />
          <stop offset="70%" stopColor="#0f172a" />
          <stop offset="100%" stopColor="#020617" />
        </radialGradient>

        {/* Backpack Gauge Gradient */}
        <linearGradient id={gaugeGradId} x1="0" y1="1" x2="0" y2="0">
          <stop offset="0%" stopColor="#fbbf24" />
          <stop offset="60%" stopColor="#f59e0b" />
          <stop offset="100%" stopColor="#d97706" />
        </linearGradient>

        {/* Highlight Specular */}
        <linearGradient id={specularHighlightId} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
      </defs>

      {/* TAIL (Behind backpack & body) */}
      <g className="animate-wave-tail origin-[200px_210px]">
        {/* Tail stroke shadow */}
        <path
          d="M 180 205 C 210 220, 245 235, 230 265 C 220 285, 200 270, 215 250 C 225 240, 240 240, 248 245"
          stroke="#0f172a"
          strokeWidth="11"
          strokeLinecap="round"
          fill="none"
        />
        {/* Tail main cyan body */}
        <path
          d="M 180 205 C 210 220, 245 235, 230 265 C 220 285, 200 270, 215 250 C 225 240, 240 240, 248 245"
          stroke="#7dd3fc"
          strokeWidth="7"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M 180 205 C 210 220, 245 235, 230 265 C 220 285, 200 270, 215 250 C 225 240, 240 240, 248 245"
          stroke="#e0f2fe"
          strokeWidth="2.5"
          strokeLinecap="round"
          fill="none"
        />
        {/* Glowing bulb tip (pure hardware accelerated without SVG filter bugs) */}
        <circle cx="248" cy="245" r="11" fill="#38bdf8" fillOpacity="0.35" />
        <circle cx="248" cy="245" r="9" fill="#0f172a" />
        <circle cx="248" cy="245" r="7" fill="#7dd3fc" />
        <circle cx="248" cy="245" r="5" fill="#e0f2fe" />
        <circle cx="246" cy="243" r="1.5" fill="#ffffff" />
      </g>

      {/* BACKPACK TANK (Right side behind body) */}
      <g id={`${prefix}_backpack`}>
        {/* Main pack chassis */}
        <rect
          x="185"
          y="110"
          width="40"
          height="80"
          rx="14"
          fill="#334155"
          stroke="#0f172a"
          strokeWidth="6"
        />
        <rect
          x="190"
          y="118"
          width="30"
          height="64"
          rx="10"
          fill="#475569"
        />
        {/* LED Indicator lights on pack */}
        <circle cx="196" cy="170" r="3" fill="#fbbf24" />
        <circle cx="204" cy="170" r="3" fill="#38bdf8" />
        <circle cx="212" cy="170" r="3" fill="#34d399" />

        {/* Thermometer / Gauge Tube */}
        <rect
          x="200"
          y="78"
          width="16"
          height="45"
          rx="8"
          fill="#0f172a"
          stroke="#0f172a"
          strokeWidth="3"
        />
        <rect
          x="202"
          y="80"
          width="12"
          height="41"
          rx="6"
          fill="#1e293b"
        />
        {/* Glowing amber liquid inside gauge */}
        <rect
          x="204"
          y="92"
          width="8"
          height="27"
          rx="4"
          fill={`url(#${gaugeGradId})`}
        />
        <line x1="204" y1="96" x2="212" y2="96" stroke="#ffffff" strokeWidth="1" strokeOpacity="0.6" />
        <line x1="204" y1="102" x2="212" y2="102" stroke="#ffffff" strokeWidth="1" strokeOpacity="0.6" />
        <line x1="204" y1="108" x2="212" y2="108" stroke="#ffffff" strokeWidth="1" strokeOpacity="0.6" />
        {/* Top cap of tube */}
        <rect x="201" y="76" width="14" height="6" rx="3" fill="#94a3b8" />
      </g>

      {/* FEET / LEGS (Bottom) */}
      <g id={`${prefix}_feet`}>
        {/* Left Foot */}
        <path
          d="M 105 225 C 100 245, 115 258, 126 248 C 132 242, 134 230, 130 220 Z"
          fill="#7dd3fc"
          stroke="#0f172a"
          strokeWidth="5"
          strokeLinejoin="round"
        />
        <path
          d="M 107 228 C 103 243, 114 252, 122 245"
          fill="#bae6fd"
        />
        {/* Right Foot */}
        <path
          d="M 148 220 C 152 238, 168 248, 178 238 C 182 230, 180 218, 172 212 Z"
          fill="#7dd3fc"
          stroke="#0f172a"
          strokeWidth="5"
          strokeLinejoin="round"
        />
        <path
          d="M 152 223 C 155 235, 166 242, 172 235"
          fill="#bae6fd"
        />
      </g>

      {/* MAIN SPHERICAL BODY - Pure vector, 100% stable on all mobile GPUs */}
      <g id={`${prefix}_body`}>
        {/* Soft Drop Shadow Layer (Pure SVG vector, never clips or disappears on mobile) */}
        <ellipse
          cx="135"
          cy="153"
          rx="86"
          ry="84"
          fill="#0369a1"
          fillOpacity="0.35"
        />

        {/* Outer dark stroke */}
        <circle
          cx="135"
          cy="145"
          r="86"
          fill="#0f172a"
        />

        {/* Main Gradient Sphere */}
        <circle
          cx="135"
          cy="145"
          r="80"
          fill={`url(#${bodyGradientId})`}
        />

        {/* Inner rim ambient light */}
        <circle
          cx="135"
          cy="145"
          r="77"
          fill="none"
          stroke="#bae6fd"
          strokeWidth="3"
          strokeOpacity="0.6"
        />

        {/* Large Glossy Specular Highlight (Top Left) */}
        <ellipse
          cx="105"
          cy="95"
          rx="32"
          ry="20"
          transform="rotate(-32 105 95)"
          fill={`url(#${specularHighlightId})`}
        />
        {/* Small Dot Highlight */}
        <circle cx="82" cy="120" r="5" fill="#ffffff" fillOpacity="0.75" />
        <circle cx="170" cy="180" r="4" fill="#ffffff" fillOpacity="0.4" />
      </g>

      {/* HARNESS BELT & CHEST BADGE */}
      <g id={`${prefix}_harness`}>
        {/* Left shoulder strap */}
        <path
          d="M 85 170 C 82 155, 78 145, 74 150 C 70 156, 75 175, 82 188"
          stroke="#0f172a"
          strokeWidth="7"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M 85 170 C 82 155, 78 145, 74 150 C 70 156, 75 175, 82 188"
          stroke="#3b82f6"
          strokeWidth="3.5"
          strokeLinecap="round"
          fill="none"
        />

        {/* Right shoulder strap to backpack */}
        <path
          d="M 185 150 C 195 155, 196 175, 185 186"
          stroke="#0f172a"
          strokeWidth="8"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M 185 150 C 195 155, 196 175, 185 186"
          stroke="#3b82f6"
          strokeWidth="4"
          strokeLinecap="round"
          fill="none"
        />

        {/* Main Chest Belt Curve */}
        <path
          d="M 75 170 C 105 195, 160 195, 190 170"
          stroke="#0f172a"
          strokeWidth="9"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M 75 170 C 105 195, 160 195, 190 170"
          stroke="#2563eb"
          strokeWidth="5"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M 82 172 C 108 193, 155 193, 182 172"
          stroke="#93c5fd"
          strokeWidth="1.5"
          strokeLinecap="round"
          fill="none"
        />

        {/* Center Circular Medallion (e⁻ Core) */}
        <g transform="translate(132, 190)">
          {/* Badge outer border */}
          <circle cx="0" cy="0" r="18" fill="#0f172a" />
          <circle cx="0" cy="0" r="15" fill={`url(#${badgeGradientId})`} stroke="#60a5fa" strokeWidth="2" />
          
          {/* Atomic orbit ellipse */}
          <ellipse cx="0" cy="0" rx="13" ry="5.5" stroke="#38bdf8" strokeWidth="1.2" transform="rotate(-25)" fill="none" opacity="0.8" />
          
          {/* Symbol e⁻ */}
          <text
            x="0"
            y="4.5"
            textAnchor="middle"
            fill="#e0f2fe"
            fontFamily="'Space Grotesk', system-ui, sans-serif"
            fontWeight="bold"
            fontSize="13"
          >
            e⁻
          </text>
        </g>
      </g>

      {/* ARMS */}
      {/* Left Arm (Waving playfully) */}
      <g
        id={`${prefix}_leftArm`}
        className={isWaving ? "origin-[70px_155px] animate-wave-tail" : ""}
      >
        {/* Arm Dark Outline */}
        <path
          d="M 74 152 C 55 138, 40 120, 36 126 C 32 134, 48 152, 68 165 Z"
          fill="#7dd3fc"
          stroke="#0f172a"
          strokeWidth="5"
          strokeLinejoin="round"
        />
        {/* Arm Highlight */}
        <path
          d="M 70 152 C 55 140, 42 125, 40 128"
          stroke="#e0f2fe"
          strokeWidth="2.5"
          strokeLinecap="round"
        />
      </g>

      {/* Right Arm (Waving up high) */}
      <g
        id={`${prefix}_rightArm`}
        className={isWaving ? "origin-[185px_150px] animate-wave-tail" : ""}
      >
        <path
          d="M 186 150 C 205 135, 218 118, 224 124 C 228 132, 210 152, 190 162 Z"
          fill="#7dd3fc"
          stroke="#0f172a"
          strokeWidth="5"
          strokeLinejoin="round"
        />
        <path
          d="M 190 148 C 206 135, 218 122, 220 125"
          stroke="#e0f2fe"
          strokeWidth="2.5"
          strokeLinecap="round"
        />
      </g>

      {/* FACIAL FEATURES */}
      <g id={`${prefix}_face`}>
        {/* Cute Eyebrows */}
        <path
          d="M 98 102 C 105 97, 115 98, 120 102"
          stroke="#0f172a"
          strokeWidth="3.5"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M 152 101 C 158 97, 168 97, 174 102"
          stroke="#0f172a"
          strokeWidth="3.5"
          strokeLinecap="round"
          fill="none"
        />

        {/* Blush Cheeks */}
        <g id={`${prefix}_blush`}>
          {/* Left Blush */}
          <ellipse cx="94" cy="144" rx="14" ry="9" fill="#f43f5e" fillOpacity="0.45" />
          <line x1="88" y1="140" x2="92" y2="148" stroke="#e11d48" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="93" y1="139" x2="97" y2="149" stroke="#e11d48" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="98" y1="140" x2="102" y2="148" stroke="#e11d48" strokeWidth="1.5" strokeLinecap="round" />

          {/* Right Blush */}
          <ellipse cx="178" cy="143" rx="14" ry="9" fill="#f43f5e" fillOpacity="0.45" />
          <line x1="172" y1="139" x2="176" y2="147" stroke="#e11d48" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="177" y1="138" x2="181" y2="148" stroke="#e11d48" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="182" y1="139" x2="186" y2="147" stroke="#e11d48" strokeWidth="1.5" strokeLinecap="round" />
        </g>

        {/* EYES - Animated / Emotional States */}
        {isBlinking || emotion === 'chill' ? (
          /* Chill / Sleeping Happy Eye Arches */
          <g id={`${prefix}_eyesClosed`}>
            <path
              d="M 98 126 C 104 136, 116 136, 122 126"
              stroke="#0f172a"
              strokeWidth="5"
              strokeLinecap="round"
              fill="none"
            />
            <path
              d="M 150 126 C 156 136, 168 136, 174 126"
              stroke="#0f172a"
              strokeWidth="5"
              strokeLinecap="round"
              fill="none"
            />
          </g>
        ) : emotion === 'energetic' ? (
          /* Energetic Star Eyes */
          <g id={`${prefix}_eyesStars`}>
            {/* Left Star Eye */}
            <circle cx="110" cy="126" r="16" fill="#0f172a" />
            <path
              d="M 110 114 L 113 123 L 122 126 L 113 129 L 110 138 L 107 129 L 98 126 L 107 123 Z"
              fill="#fbbf24"
            />
            <circle cx="114" cy="122" r="2.5" fill="#ffffff" />

            {/* Right Star Eye */}
            <circle cx="162" cy="125" r="16" fill="#0f172a" />
            <path
              d="M 162 113 L 165 122 L 174 125 L 165 128 L 162 137 L 159 128 L 150 125 L 159 122 Z"
              fill="#fbbf24"
            />
            <circle cx="166" cy="121" r="2.5" fill="#ffffff" />
          </g>
        ) : (
          /* Classic Sparkling Anime Kawaii Eyes */
          <g id={`${prefix}_eyesNormal`}>
            {/* Left Eye */}
            <g>
              <ellipse cx="110" cy="127" rx="14" ry="18" fill="#0f172a" />
              {/* Eye bottom violet accent */}
              <ellipse cx="110" cy="135" rx="10" ry="7" fill="#312e81" opacity="0.7" />
              {/* Large highlight */}
              <circle cx="106" cy="120" r="6" fill="#ffffff" />
              {/* Secondary highlight */}
              <circle cx="115" cy="133" r="3.5" fill="#ffffff" />
              {/* Micro highlight */}
              <circle cx="116" cy="123" r="1.8" fill="#ffffff" />
            </g>

            {/* Right Eye */}
            <g>
              <ellipse cx="162" cy="126" rx="14" ry="18" fill="#0f172a" />
              {/* Eye bottom violet accent */}
              <ellipse cx="162" cy="134" rx="10" ry="7" fill="#312e81" opacity="0.7" />
              {/* Large highlight */}
              <circle cx="158" cy="119" r="6" fill="#ffffff" />
              {/* Secondary highlight */}
              <circle cx="167" cy="132" r="3.5" fill="#ffffff" />
              {/* Micro highlight */}
              <circle cx="168" cy="122" r="1.8" fill="#ffffff" />
            </g>
          </g>
        )}

        {/* MOUTH */}
        {emotion === 'curious' ? (
          <ellipse cx="136" cy="144" rx="4" ry="6" fill="#0f172a" />
        ) : emotion === 'energetic' ? (
          /* Wide open happy mouth */
          <g>
            <path
              d="M 126 138 Q 136 155 146 138 Z"
              fill="#e11d48"
              stroke="#0f172a"
              strokeWidth="3"
            />
            <path
              d="M 129 146 Q 136 142 143 146 Q 136 153 129 146 Z"
              fill="#fb7185"
            />
          </g>
        ) : (
          /* Sweet curved smile :3 */
          <path
            d="M 128 138 Q 136 147 144 138"
            stroke="#0f172a"
            strokeWidth="3.5"
            strokeLinecap="round"
            fill="none"
          />
        )}
      </g>
    </svg>
  );
};
