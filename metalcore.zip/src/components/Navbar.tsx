import React, { useState, useEffect } from 'react';
import { BookOpen, Gamepad2, Atom, HelpCircle, Sparkles, Menu, X, ArrowUpRight, Sun, Moon } from 'lucide-react';
import { soundManager } from '../utils/soundFx';
import { useTheme } from '../context/ThemeContext';

export const Navbar: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 15);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Tạp Chí Flipbook', href: '#flipbook-section', icon: BookOpen },
    { label: 'Trạm Mini-Apps (6)', href: '#interactive-stations', icon: Gamepad2 },
    { label: 'Mô Phỏng Biển e⁻', href: '#magazine-articles', icon: Atom },
    { label: 'Thử Thách Hóa Học', href: '#electron-quiz', icon: HelpCircle },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    soundManager.playBubblePop();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleThemeToggle = () => {
    soundManager.playBubblePop();
    toggleTheme();
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-40 w-full transition-all duration-300 ${
      scrolled 
        ? 'bg-slate-950/90 dark:bg-slate-950/90 light-theme:bg-white/90 backdrop-blur-md border-b border-sky-500/20 shadow-lg py-2.5 sm:py-3' 
        : 'bg-transparent py-3 sm:py-5'
    }`}>
      <div className="max-w-7xl mx-auto px-3.5 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand / Logo */}
        <a 
          href="#" 
          className="flex items-center gap-2.5 sm:gap-3 group shrink-0"
          onClick={() => soundManager.playElectronChirp()}
        >
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-tr from-sky-500 to-cyan-400 p-0.5 shadow-lg shadow-sky-500/30 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <span className="font-extrabold text-sky-400 text-xs sm:text-sm tracking-tighter">e⁻</span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-sm sm:text-base tracking-wider text-white">METAL</span>
              <span className="font-extrabold text-sm sm:text-base tracking-wider bg-gradient-to-r from-sky-400 to-cyan-300 bg-clip-text text-transparent">CORE</span>
              <span className="text-[9px] sm:text-[10px] font-bold px-1.5 py-0.2 rounded bg-sky-950 text-sky-400 border border-sky-800">12A2</span>
            </div>
            <p className="text-[9px] sm:text-[10px] text-slate-400 tracking-tight font-medium hidden xs:block">Tạp Chí Khoa Học Kim Loại</p>
          </div>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-1.5 bg-slate-900/70 border border-slate-800/80 rounded-full px-4 py-1.5 backdrop-blur-md">
          {navLinks.map((item) => {
            const Icon = item.icon;
            return (
              <a
                key={item.href}
                href={item.href}
                onClick={(e) => handleLinkClick(e, item.href)}
                className="px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-sky-300 hover:bg-slate-800/80 rounded-full transition-colors flex items-center gap-1.5"
              >
                <Icon className="w-3.5 h-3.5 text-sky-400" />
                <span>{item.label}</span>
              </a>
            );
          })}
        </nav>

        {/* Right Controls: Theme Toggle + Heyzine Link + Mobile Menu Button */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Light / Dark Mode Toggle Button */}
          <button
            onClick={handleThemeToggle}
            className="p-2 sm:px-3 sm:py-2 rounded-xl bg-slate-900/90 border border-slate-700/80 hover:border-sky-400 text-slate-200 transition-all cursor-pointer flex items-center gap-1.5 text-xs font-medium shadow-sm hover:scale-105"
            title={theme === 'dark' ? "Chuyển sang Chế độ Sáng (Light Mode)" : "Chuyển sang Chế độ Tối (Dark Mode)"}
            aria-label="Toggle light dark theme"
          >
            {theme === 'dark' ? (
              <>
                <Sun className="w-4 h-4 text-amber-400 animate-spin-slow" />
                <span className="hidden sm:inline text-amber-300">Sáng</span>
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 text-sky-500" />
                <span className="hidden sm:inline text-sky-700">Tối</span>
              </>
            )}
          </button>

          {/* Heyzine Fullscreen / External CTA */}
          <a
            href="https://heyzine.com/flip-book/0403fd6e29.html"
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => soundManager.playSuccess()}
            className="hidden sm:flex px-3.5 py-2 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-400 hover:to-cyan-400 text-white font-bold text-xs shadow-lg shadow-sky-500/25 transition-all items-center gap-1.5 hover:scale-105 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Mở Heyzine Full HD</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white lg:hidden cursor-pointer"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-950/95 border-b border-sky-500/25 px-4 py-4 backdrop-blur-xl animate-in slide-in-from-top-2 shadow-2xl">
          <div className="flex flex-col gap-2">
            {navLinks.map((item) => {
              const Icon = item.icon;
              return (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={(e) => handleLinkClick(e, item.href)}
                  className="px-4 py-2.5 rounded-xl text-sm font-semibold text-slate-200 hover:bg-slate-900 flex items-center gap-2.5 transition-colors"
                >
                  <Icon className="w-4 h-4 text-sky-400" />
                  <span>{item.label}</span>
                </a>
              );
            })}
            <a
              href="https://heyzine.com/flip-book/0403fd6e29.html"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-cyan-600 text-white font-bold text-center text-sm flex items-center justify-center gap-2 shadow-lg"
            >
              <Sparkles className="w-4 h-4" />
              <span>Mở Flipbook Gốc (40 Trang)</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
