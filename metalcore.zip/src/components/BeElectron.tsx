import React, { useState, useEffect, useRef } from 'react';
import { EmotionType, OutfitType, MovementMode } from '../types';
import { soundManager } from '../utils/soundFx';
import { ElectronMascotArtwork } from './ElectronMascotArtwork';
import { 
  Sparkles, 
  Settings2, 
  Volume2, 
  VolumeX, 
  Move, 
  Heart, 
  X,
  Minimize2,
  Maximize2,
  Smile
} from 'lucide-react';

interface BeElectronProps {
  currentSection?: string;
}

const CHEMISTRY_QUIPS: Record<string, string[]> = {
  general: [
    "Chào bạn! Tớ là Bé Electron – hạt mang điện tích âm e = -1.6 × 10⁻¹⁹ C đồng hành cùng bạn!",
    "Trong tinh thể kim loại, tớ và hàng tỉ bạn electron tự do lướt đi tạo thành 'biển electron' thần kỳ!",
    "Bạn có biết: Kim loại dẫn điện tốt nhất theo thứ tự là Bạc (Ag) > Đồng (Cu) > Vàng (Au) > Nhôm (Al) > Sắt (Fe)!",
    "Hãy mở flipbook 40 trang ở trên để cùng khám phá trọn vẹn lý thuyết đại cương kim loại 12 nha!",
    "Nhiệt độ nóng chảy kỉ lục thuộc về Wolfram (W) đạt tới 3410°C, dùng làm dây tóc bóng đèn siêu bền!"
  ],
  structure: [
    "Ở phần Cấu tạo & Liên kết: Kim loại có bán kính nguyên tử lớn hơn phi kim cùng chu kì nhưng ít electron hóa trị hơn!",
    "Liên kết kim loại hình thành do lực hút tĩnh điện giữa cation kim loại và các electron tự do bọn tớ!",
    "Bạn hãy mở mini-game Electron Escape ở trang 9 để cùng tớ lượn qua mạng tinh thể nhé!"
  ],
  properties: [
    "Ánh kim lấp lánh, dẫn điện, dẫn nhiệt, tính dẻo đều do các electron tự do bọn tớ tạo nên đó!",
    "Tính khử của kim loại: M → Mⁿ⁺ + ne⁻. Bọn tớ luôn sẵn sàng bay ra nhường điện tích!",
    "Lưu ý bẫy đề thi: Al, Fe, Cr bị thụ động hóa hoàn toàn trong HNO₃ đặc nguội và H₂SO₄ đặc nguội!"
  ],
  extraction: [
    "Nguyên tắc điều chế kim loại là khử ion kim loại: Mⁿ⁺ + ne⁻ → M!",
    "Kim loại mạnh (từ K đến Al) phải dùng phương pháp điện phân nóng chảy hợp chất mới ép tớ về lại được!",
    "Nhớ ghé chơi game Thám tử hóa học ở trang 26 để phá án mẫu vật bí ẩn nhé!"
  ],
  alloy: [
    "Hợp kim của sắt gồm Gang (2 - 5% C) và Thép (0.01 - 2% C). Thép dẻo và chịu lực cực tốt!",
    "Đồng dẫn điện tốt hơn hợp kim đồng, nhưng hợp kim thì cứng và bền hơn nhiều lần!",
    "Khám phá web Hợp Kim để xem siêu hợp kim Duralumin nhẹ chế tạo thân máy bay nha!"
  ],
  corrosion: [
    "Ăn mòn điện hóa cần 3 điều kiện: 2 điện cực khác nhau, tiếp xúc điện, và cùng tiếp xúc dung dịch điện li!",
    "Để cứu tàu biển bằng thép Fe, các kỹ sư gắn những khối Kẽm (Zn) vào vỏ tàu để Zn bị ăn mòn hi sinh!",
    "Bạn hãy chơi trò 'Save The Ship' ở trang 36 để thử tài cứu tàu vượt bão biển nha!"
  ]
};

export const BeElectron: React.FC<BeElectronProps> = ({ currentSection = 'general' }) => {
  // Mascot state
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [isMinimized, setIsMinimized] = useState(false);
  const [showCustomizer, setShowCustomizer] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isBlinking, setIsBlinking] = useState(false);
  const [isWiggling, setIsWiggling] = useState(false);

  // Customization options
  const [emotion, setEmotion] = useState<EmotionType>('happy');
  const [outfit, setOutfit] = useState<OutfitType>('classic');
  const [movementMode, setMovementMode] = useState<MovementMode>('docked');
  const [size, setSize] = useState<'sm' | 'md' | 'lg'>('md');
  const [renderMode, setRenderMode] = useState<'vector' | 'photo'>('vector');

  // Interactive speech
  const [speechText, setSpeechText] = useState<string>("Chào bạn! Tớ là Bé Electron, bạn đồng hành trên tạp chí Metal Core!");
  const [showBubble, setShowBubble] = useState(true);

  const containerRef = useRef<HTMLDivElement>(null);

  // Blinking timer effect
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setIsBlinking(true);
      setTimeout(() => setIsBlinking(false), 180);
    }, 4200);

    return () => clearInterval(blinkInterval);
  }, []);

  // Initialize position on screen safely without overflowing
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const isMobile = window.innerWidth < 640;
      const initialX = isMobile ? window.innerWidth - 130 : window.innerWidth - 170;
      const initialY = isMobile ? window.innerHeight - 180 : window.innerHeight - 220;
      setPosition({
        x: Math.max(10, initialX),
        y: Math.max(70, initialY)
      });
    }
  }, []);

  // Update speech when current section changes
  useEffect(() => {
    const quipList = CHEMISTRY_QUIPS[currentSection] || CHEMISTRY_QUIPS.general;
    const randomQuip = quipList[Math.floor(Math.random() * quipList.length)];
    setSpeechText(randomQuip);
    setShowBubble(true);
    soundManager.playBubblePop();
  }, [currentSection]);

  // Handle follow scroll mode
  useEffect(() => {
    if (movementMode !== 'follow_scroll') return;

    const handleScroll = () => {
      const scrollY = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = docHeight > 0 ? scrollY / docHeight : 0;
      
      const isMobile = window.innerWidth < 640;
      const targetY = 100 + progress * (window.innerHeight - (isMobile ? 240 : 320)) + Math.sin(scrollY / 120) * 12;
      const clampedY = Math.max(80, Math.min(window.innerHeight - (isMobile ? 180 : 220), targetY));
      
      setPosition({
        x: window.innerWidth - (isMobile ? 130 : 170),
        y: clampedY
      });
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [movementMode]);

  // Handle follow mouse mode (desktop only)
  useEffect(() => {
    if (movementMode !== 'follow_mouse' || window.innerWidth < 768) return;

    const handleMouseMove = (e: MouseEvent) => {
      const targetX = Math.max(15, Math.min(window.innerWidth - 170, e.clientX + 35));
      const targetY = Math.max(80, Math.min(window.innerHeight - 200, e.clientY - 40));
      setPosition({ x: targetX, y: targetY });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [movementMode]);

  // Free drag handlers with screen clamping
  const handlePointerDown = (e: React.PointerEvent) => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    if ((e.target as HTMLElement).closest('button')) return;

    const rect = containerRef.current?.getBoundingClientRect();
    const currentX = rect ? rect.left : position.x;
    const currentY = rect ? rect.top : position.y;

    setPosition({ x: currentX, y: currentY });
    setDragOffset({
      x: e.clientX - currentX,
      y: e.clientY - currentY
    });

    setIsDragging(true);
    setMovementMode('free_drag');
    try {
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
    } catch {
      // Ignore
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const isMobile = window.innerWidth < 640;
    const maxX = window.innerWidth - (isMobile ? 120 : 160);
    const maxY = window.innerHeight - (isMobile ? 140 : 180);

    const newX = Math.max(10, Math.min(maxX, e.clientX - dragOffset.x));
    const newY = Math.max(60, Math.min(maxY, e.clientY - dragOffset.y));
    setPosition({ x: newX, y: newY });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (isDragging) {
      setIsDragging(false);
      try {
        (e.target as HTMLElement).releasePointerCapture(e.pointerId);
      } catch {
        // Ignore
      }
    }
  };

  // Interaction when clicked
  const handleMascotClick = () => {
    soundManager.playElectronChirp();
    setIsWiggling(true);
    setTimeout(() => setIsWiggling(false), 600);

    const quipList = CHEMISTRY_QUIPS[currentSection] || CHEMISTRY_QUIPS.general;
    const randomQuip = quipList[Math.floor(Math.random() * quipList.length)];
    setSpeechText(randomQuip);
    setShowBubble(true);
  };

  const toggleMute = () => {
    const nextState = !isMuted;
    setIsMuted(nextState);
    soundManager.setMuted(nextState);
  };

  // Dimensions by size
  const sizeClasses = {
    sm: 'w-20 h-20 sm:w-24 sm:h-24',
    md: 'w-24 h-24 sm:w-32 sm:h-32',
    lg: 'w-32 h-32 sm:w-44 sm:h-44'
  }[size];

  return (
    <>
      {/* Floating or Docked Container with strict viewport bounds and top-level z-index */}
      <div
        ref={containerRef}
        style={{
          transform: movementMode === 'docked' 
            ? 'translateZ(0)' 
            : `translate3d(${position.x}px, ${position.y}px, 0)`,
          transition: isDragging ? 'none' : 'transform 0.35s cubic-bezier(0.2, 0.8, 0.2, 1)',
          bottom: movementMode === 'docked' ? 'max(16px, env(safe-area-inset-bottom, 16px))' : undefined,
          right: movementMode === 'docked' ? 'max(16px, env(safe-area-inset-right, 16px))' : undefined,
          willChange: 'transform',
          backfaceVisibility: 'hidden',
          WebkitBackfaceVisibility: 'hidden',
        }}
        className={`fixed z-[9999] select-none max-w-[calc(100vw-1rem)] pointer-events-auto ${
          movementMode === 'docked' ? '' : 'top-0 left-0'
        }`}
      >
        <div className="relative flex flex-col items-end">
          {/* Speech Bubble (Responsive constrained width) */}
          {showBubble && !isMinimized && (
            <div className="relative mb-2.5 w-[260px] sm:w-[320px] max-w-[calc(100vw-2.5rem)] rounded-2xl bg-slate-900/95 border border-sky-400/50 p-3 sm:p-3.5 shadow-2xl backdrop-blur-xl text-slate-100 text-xs sm:text-sm animate-in fade-in zoom-in-95 duration-200">
              <div className="flex items-start justify-between gap-2 mb-1.5 border-b border-sky-500/20 pb-1">
                <span className="font-bold flex items-center gap-1.5 text-sky-400 text-xs sm:text-sm">
                  <span className="inline-block w-2 h-2 rounded-full bg-sky-400 animate-ping" />
                  Bé Electron mách bạn:
                </span>
                <button
                  onClick={() => setShowBubble(false)}
                  className="text-slate-400 hover:text-white p-0.5 rounded cursor-pointer transition-colors"
                  title="Ẩn lời thoại"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="leading-relaxed text-slate-200 text-[11px] sm:text-xs">{speechText}</p>
              
              {/* Quick actions inside bubble */}
              <div className="mt-2 pt-1.5 border-t border-slate-800 flex items-center justify-between gap-1 text-[10px] sm:text-[11px] text-sky-300">
                <button
                  onClick={handleMascotClick}
                  className="hover:text-sky-100 underline underline-offset-2 flex items-center gap-1 cursor-pointer"
                >
                  <Sparkles className="w-3 h-3 text-amber-300" />
                  Mẹo khác
                </button>
                <button
                  onClick={() => setShowCustomizer(true)}
                  className="hover:text-white flex items-center gap-1 cursor-pointer bg-sky-950/80 px-2 py-0.5 rounded-full border border-sky-700/60"
                >
                  <Settings2 className="w-3 h-3 text-sky-400" />
                  Tùy biến Bé
                </button>
              </div>

              {/* Triangle Tail */}
              <div className="absolute -bottom-2 right-8 sm:right-12 w-3 h-3 bg-slate-900 border-r border-b border-sky-400/50 transform rotate-45" />
            </div>
          )}

          {/* Minimized Pill */}
          {isMinimized ? (
            <button
              onClick={() => setIsMinimized(false)}
              className="flex items-center gap-2 px-3 py-2 rounded-full bg-sky-600 hover:bg-sky-500 text-white font-medium text-xs shadow-lg shadow-sky-500/40 transition-all hover:scale-105 cursor-pointer border border-sky-300/40"
            >
              <div className="w-6 h-6 rounded-full bg-sky-200 flex items-center justify-center text-sky-950 font-bold text-[10px]">
                e⁻
              </div>
              <span className="text-[11px] font-bold">Gọi Bé Electron</span>
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          ) : (
            /* Full Mascot Avatar and Controls */
            <div className="relative group">
              {/* Quick floating toolbar */}
              <div className="absolute -top-7 right-0 flex items-center gap-1 bg-slate-900/90 px-2 py-1 rounded-full border border-sky-500/40 shadow-lg text-slate-300 text-xs">
                <button
                  onClick={() => setShowCustomizer(true)}
                  className="hover:text-sky-300 p-0.5 rounded cursor-pointer"
                  title="Tùy chỉnh biểu cảm & trang phục"
                >
                  <Settings2 className="w-3.5 h-3.5 text-sky-400" />
                </button>
                <button
                  onClick={toggleMute}
                  className="hover:text-sky-300 p-0.5 rounded cursor-pointer"
                  title={isMuted ? "Bật âm thanh" : "Tắt âm thanh"}
                >
                  {isMuted ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5 text-sky-400" />}
                </button>
                <button
                  onClick={() => setIsMinimized(true)}
                  className="hover:text-sky-300 p-0.5 rounded cursor-pointer"
                  title="Thu nhỏ bé lại"
                >
                  <Minimize2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Character Visual Container */}
              <div
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onClick={handleMascotClick}
                className={`relative cursor-grab active:cursor-grabbing transition-transform ${
                  isWiggling ? 'animate-mascot-wiggle' : 'sm:hover:scale-105'
                } ${sizeClasses}`}
                title="Bé Electron: Chạm hoặc kéo thả để vui chơi cùng bé!"
              >
                {/* Visual Auras */}
                {outfit === 'golden_aura' && (
                  <div className="absolute inset-0 rounded-full bg-amber-400/30 blur-xl animate-pulse pointer-events-none" />
                )}
                {outfit === 'plasma_shield' && (
                  <div className="absolute -inset-2 rounded-full border-2 border-dashed border-sky-400 animate-spin pointer-events-none opacity-80" />
                )}

                {/* Main Render: Vector Chibi (matches original sticker art) vs Photographic */}
                <div className="w-full h-full relative animate-electron-float">
                  {renderMode === 'vector' ? (
                    <ElectronMascotArtwork
                      idPrefix="companion_mascot"
                      emotion={emotion}
                      isBlinking={isBlinking}
                      className="w-full h-full"
                    />
                  ) : (
                    <img
                      src="/images/be-electron-pure.png"
                      alt="Bé Electron Mascot"
                      className="w-full h-full object-contain filter drop-shadow-[0_0_16px_rgba(56,189,248,0.7)] pointer-events-none"
                      onError={() => setRenderMode('vector')}
                    />
                  )}

                  {/* Accessory Overlays */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    {/* Goggles accessory */}
                    {outfit === 'goggles' && (
                      <div className="absolute top-[28%] left-1/2 -translate-x-1/2 flex items-center gap-1 z-20">
                        <div className="w-6 sm:w-7 h-4 sm:h-5 rounded-full border-2 border-emerald-400 bg-emerald-500/40 backdrop-blur-sm flex items-center justify-center shadow-lg shadow-emerald-500/50">
                          <div className="w-1.5 h-1 bg-white/80 rounded-full -rotate-45" />
                        </div>
                        <div className="w-2 h-0.5 bg-emerald-400" />
                        <div className="w-6 sm:w-7 h-4 sm:h-5 rounded-full border-2 border-emerald-400 bg-emerald-500/40 backdrop-blur-sm flex items-center justify-center shadow-lg shadow-emerald-500/50">
                          <div className="w-1.5 h-1 bg-white/80 rounded-full -rotate-45" />
                        </div>
                      </div>
                    )}

                    {/* Professor Hat accessory */}
                    {outfit === 'professor' && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center">
                        <div className="w-11 sm:w-14 h-3 bg-amber-500 rounded-sm shadow-md" />
                        <div className="w-9 sm:w-11 h-2 bg-amber-600 rounded-t-sm" />
                        <div className="absolute top-1 right-2 w-1 h-5 border-r-2 border-yellow-300" />
                      </div>
                    )}

                    {/* Additional Emotion Overlays */}
                    {emotion === 'scientist' && (
                      <div className="absolute -top-1 -left-1 text-[10px] sm:text-xs font-bold text-sky-300 bg-slate-900/95 rounded-full px-1.5 py-0.5 border border-sky-400 shadow-sm">
                        e⁻
                      </div>
                    )}
                    {emotion === 'curious' && (
                      <div className="absolute -top-2 right-1 text-sky-400 font-bold text-sm sm:text-base animate-bounce">
                        ?
                      </div>
                    )}
                    {emotion === 'chill' && (
                      <div className="absolute -top-2 right-1 text-sky-300 font-mono text-xs font-bold">
                        zZz
                      </div>
                    )}
                  </div>
                </div>

                {/* Sub-badge indicating charge */}
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-sky-950/90 border border-sky-400/70 text-sky-300 text-[9px] sm:text-[10px] font-bold px-2 py-0.5 rounded-full shadow-md backdrop-blur-md pointer-events-none whitespace-nowrap">
                  e⁻ 1.6×10⁻¹⁹C
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Customizer Modal / Drawer */}
      {showCustomizer && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg rounded-3xl bg-slate-900 border border-sky-500/40 p-5 sm:p-6 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            {/* Glowing background aura */}
            <div className="absolute -top-24 -right-24 w-60 h-60 rounded-full bg-sky-500/15 blur-3xl pointer-events-none" />
            <div className="absolute -bottom-24 -left-24 w-60 h-60 rounded-full bg-indigo-500/15 blur-3xl pointer-events-none" />

            <div className="flex items-center justify-between pb-3.5 border-b border-slate-800 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-500 to-cyan-400 flex items-center justify-center text-white shadow-lg shadow-sky-500/30 font-bold">
                  e⁻
                </div>
                <div>
                  <h3 className="font-bold text-base sm:text-lg text-white">Phòng Lab Bé Electron</h3>
                  <p className="text-xs text-sky-400">Tùy biến biểu cảm, phong cách & cử động</p>
                </div>
              </div>
              <button
                onClick={() => setShowCustomizer(false)}
                className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 space-y-4 overflow-y-auto pr-1 flex-1">
              {/* Graphic Style Switch (Bản B sticker vs 3D) */}
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 block flex items-center gap-1.5">
                  <Smile className="w-3.5 h-3.5 text-cyan-400" />
                  Phong cách hình ảnh Bé Electron
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setRenderMode('vector')}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      renderMode === 'vector'
                        ? 'border-sky-400 bg-sky-950/70 text-white font-bold shadow-md shadow-sky-500/20'
                        : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    <div className="text-xs text-sky-300">Vector Sticker Chibi (Bản B Chuẩn)</div>
                    <div className="text-[10px] text-slate-400">Đồ họa sắc nét 100%, cử động mượt, trong suốt</div>
                  </button>

                  <button
                    onClick={() => setRenderMode('photo')}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      renderMode === 'photo'
                        ? 'border-sky-400 bg-sky-950/70 text-white font-bold shadow-md shadow-sky-500/20'
                        : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    <div className="text-xs text-sky-300">Hiệu ứng 3D Render</div>
                    <div className="text-[10px] text-slate-400">Hình ảnh minh họa đổ bóng nổi khối</div>
                  </button>
                </div>
              </div>

              {/* Movement Mode */}
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 block flex items-center gap-1.5">
                  <Move className="w-3.5 h-3.5 text-sky-400" />
                  Chế độ di chuyển của bé
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'docked', label: 'Cố định góc dưới', desc: 'Gọn gàng trên màn hình' },
                    { id: 'follow_scroll', label: 'Lượn theo thanh cuộn', desc: 'Bơi theo trang khi bạn đọc' },
                    { id: 'follow_mouse', label: 'Đuổi theo con trỏ', desc: 'Bay theo cử chỉ chuột' },
                    { id: 'free_drag', label: 'Tự do kéo thả', desc: 'Kéo đặt ở bất cứ đâu' }
                  ].map(m => (
                    <button
                      key={m.id}
                      onClick={() => setMovementMode(m.id as MovementMode)}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        movementMode === m.id
                          ? 'border-sky-400 bg-sky-950/70 text-white shadow-md shadow-sky-500/20'
                          : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:bg-slate-800'
                      }`}
                    >
                      <div className="font-bold text-xs text-sky-300">{m.label}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{m.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Emotion Selection */}
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 block flex items-center gap-1.5">
                  <Heart className="w-3.5 h-3.5 text-pink-400" />
                  Biểu cảm / Cảm xúc
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                  {[
                    { id: 'happy', label: 'Vui vẻ', emoji: '😄' },
                    { id: 'scientist', label: 'Bác học', emoji: '🔬' },
                    { id: 'energetic', label: 'Tích điện', emoji: '⚡' },
                    { id: 'curious', label: 'Tò mò', emoji: '🤔' },
                    { id: 'chill', label: 'Thư giãn', emoji: '💤' }
                  ].map(emo => (
                    <button
                      key={emo.id}
                      onClick={() => {
                        setEmotion(emo.id as EmotionType);
                        soundManager.playBubblePop();
                      }}
                      className={`p-2 rounded-xl border flex flex-col items-center gap-1 transition-all cursor-pointer ${
                        emotion === emo.id
                          ? 'border-sky-400 bg-sky-950/80 text-white font-bold'
                          : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:bg-slate-800'
                      }`}
                    >
                      <span className="text-lg">{emo.emoji}</span>
                      <span className="text-[11px]">{emo.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Outfit / Accessories */}
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 block flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  Trang phục & Phụ kiện
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'classic', label: 'Nguyên bản', desc: 'Phi hành gia xanh' },
                    { id: 'goggles', label: 'Kính bảo hộ Lab', desc: 'Bảo vệ mắt thí nghiệm' },
                    { id: 'professor', label: 'Mũ giáo sư', desc: 'Nắm chắc 10 điểm Hóa' },
                    { id: 'golden_aura', label: 'Hào quang vàng', desc: 'Ánh kim rực rỡ' },
                    { id: 'plasma_shield', label: 'Lá chắn Plasma', desc: 'Vòng xoay điện tích' }
                  ].map(acc => (
                    <button
                      key={acc.id}
                      onClick={() => {
                        setOutfit(acc.id as OutfitType);
                        soundManager.playElectricZap();
                      }}
                      className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                        outfit === acc.id
                          ? 'border-cyan-400 bg-cyan-950/70 text-white font-bold shadow-md shadow-cyan-500/20'
                          : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:bg-slate-800'
                      }`}
                    >
                      <div className="text-xs text-cyan-300">{acc.label}</div>
                      <div className="text-[10px] text-slate-400">{acc.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Size and Sound */}
              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800">
                <div>
                  <label className="text-xs font-semibold text-slate-400 mb-1.5 block">Kích thước bé</label>
                  <div className="flex rounded-xl bg-slate-800 p-1 border border-slate-700">
                    {(['sm', 'md', 'lg'] as const).map(s => (
                      <button
                        key={s}
                        onClick={() => setSize(s)}
                        className={`flex-1 py-1 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
                          size === s ? 'bg-sky-500 text-white font-bold' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {s === 'sm' ? 'Nhỏ' : s === 'md' ? 'Chuẩn' : 'Lớn'}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-400 mb-1.5 block">Âm thanh tương tác</label>
                  <button
                    onClick={toggleMute}
                    className={`w-full py-1.5 px-3 rounded-xl border text-xs font-medium flex items-center justify-center gap-2 cursor-pointer transition-colors ${
                      isMuted
                        ? 'border-rose-800 bg-rose-950/50 text-rose-300'
                        : 'border-sky-800 bg-sky-950/50 text-sky-300'
                    }`}
                  >
                    {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                    {isMuted ? 'Đang tắt tiếng' : 'Âm thanh bật'}
                  </button>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="mt-4 flex justify-end gap-3 pt-3 border-t border-slate-800 shrink-0">
              <button
                onClick={() => {
                  soundManager.playSuccess();
                  setShowCustomizer(false);
                }}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-400 hover:to-cyan-400 text-white font-bold text-xs sm:text-sm shadow-lg shadow-sky-500/30 transition-all cursor-pointer"
              >
                Lưu cài đặt & Bay cùng Bé!
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
