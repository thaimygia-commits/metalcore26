import { useState, useEffect } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { FlipbookViewer } from './components/FlipbookViewer';
import { InteractiveStations } from './components/InteractiveStations';
import { MagazineArticles } from './components/MagazineArticles';
import { ElectronQuiz } from './components/ElectronQuiz';
import { Footer } from './components/Footer';
import { BeElectron } from './components/BeElectron';

export function App() {
  const [currentSection, setCurrentSection] = useState<string>('general');

  // Track active section for contextual Bé Electron quips
  useEffect(() => {
    const handleScroll = () => {
      const scrollPos = window.scrollY + 280;

      const flipbookEl = document.getElementById('flipbook-section');
      const stationsEl = document.getElementById('interactive-stations');
      const articlesEl = document.getElementById('magazine-articles');
      const quizEl = document.getElementById('electron-quiz');

      if (quizEl && scrollPos >= quizEl.offsetTop) {
        setCurrentSection('corrosion');
      } else if (articlesEl && scrollPos >= articlesEl.offsetTop) {
        setCurrentSection('structure');
      } else if (stationsEl && scrollPos >= stationsEl.offsetTop) {
        setCurrentSection('properties');
      } else if (flipbookEl && scrollPos >= flipbookEl.offsetTop) {
        setCurrentSection('general');
      } else {
        setCurrentSection('general');
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <ThemeProvider>
      <div className="min-h-screen w-full max-w-full overflow-x-clip relative font-sans selection:bg-sky-500 selection:text-white">
        {/* Subtle Chemical Grid & Orbital Particle Background */}
        <div className="fixed inset-0 magazine-grid opacity-35 pointer-events-none z-0" />
        <div className="fixed top-0 left-0 w-full h-[500px] bg-gradient-to-b from-sky-500/10 via-transparent to-transparent pointer-events-none z-0" />

        {/* Main Website Structure */}
        <div className="relative z-10 w-full max-w-full overflow-x-clip">
          <Navbar />
          <main className="w-full max-w-full overflow-x-clip">
            <HeroSection />
            <FlipbookViewer />
            <InteractiveStations />
            <MagazineArticles />
            <ElectronQuiz />
          </main>
          <Footer />
        </div>
      </div>

      {/* Interactive Mascot Companion placed at root outside of any overflow-x-clip parent */}
      <BeElectron currentSection={currentSection} />
    </ThemeProvider>
  );
}

export default App;
