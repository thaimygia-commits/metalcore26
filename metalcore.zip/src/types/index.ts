export type EmotionType = 'happy' | 'scientist' | 'energetic' | 'curious' | 'chill';

export type OutfitType = 'classic' | 'goggles' | 'professor' | 'golden_aura' | 'plasma_shield';

export type MovementMode = 'follow_scroll' | 'follow_mouse' | 'free_drag' | 'docked';

export interface InteractiveStation {
  id: string;
  title: string;
  category: 'game' | 'simulation' | 'puzzle' | 'review';
  url: string;
  description: string;
  pageInFlipbook: number;
  highlightTag: string;
  color: string;
  icon: string;
  electronHint: string;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  pageRef: number;
}
